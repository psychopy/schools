﻿/*************** 
 * Demo_1 Test *
 ***************/

import { core, data, sound, util, visual, hardware } from './lib/psychojs-2022.2.0.js';
const { PsychoJS } = core;
const { TrialHandler, MultiStairHandler } = data;
const { Scheduler } = util;
//some handy aliases as in the psychopy scripts;
const { abs, sin, cos, PI: pi, sqrt } = Math;
const { round } = util;


// store info about the experiment session:
let expName = 'demo_1';  // from the Builder filename that created this script
let expInfo = {
    'participant': '',
    'session': '001',
};

// Start code blocks for 'Before Experiment'
// init psychoJS:
const psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: true,
  color: new util.Color([0,0,0]),
  units: 'height',
  waitBlanking: true
});
// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
const instrLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(instrLoopBegin(instrLoopScheduler));
flowScheduler.add(instrLoopScheduler);
flowScheduler.add(instrLoopEnd);
const scanLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(scanLoopBegin(scanLoopScheduler));
flowScheduler.add(scanLoopScheduler);
flowScheduler.add(scanLoopEnd);
flowScheduler.add(startRoutineBegin());
flowScheduler.add(startRoutineEachFrame());
flowScheduler.add(startRoutineEnd());
const trialsLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trialsLoopBegin(trialsLoopScheduler));
flowScheduler.add(trialsLoopScheduler);
flowScheduler.add(trialsLoopEnd);
flowScheduler.add(endRoutineBegin());
flowScheduler.add(endRoutineEachFrame());
flowScheduler.add(endRoutineEnd());
flowScheduler.add(quitPsychoJS, '', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, '', false);

psychoJS.start({
  expName: expName,
  expInfo: expInfo,
  resources: [
    {'name': 'stimuli/stim/Slide8.JPG', 'path': 'stimuli/stim/Slide8.JPG'},
    {'name': 'stimuli/stim/Slide1.JPG', 'path': 'stimuli/stim/Slide1.JPG'},
    {'name': 'stimuli/stim/Slide10.JPG', 'path': 'stimuli/stim/Slide10.JPG'},
    {'name': 'stimuli/stim/Slide3.JPG', 'path': 'stimuli/stim/Slide3.JPG'},
    {'name': 'scanning.xlsx', 'path': 'scanning.xlsx'},
    {'name': 'stimuli/stim/Slide6.JPG', 'path': 'stimuli/stim/Slide6.JPG'},
    {'name': 'trials.xlsx', 'path': 'trials.xlsx'},
    {'name': 'stimuli/stim/Slide2.JPG', 'path': 'stimuli/stim/Slide2.JPG'},
    {'name': 'stimuli/stim/Slide5.JPG', 'path': 'stimuli/stim/Slide5.JPG'},
    {'name': 'stimuli/stim/Slide4.JPG', 'path': 'stimuli/stim/Slide4.JPG'},
    {'name': 'stimuli/stim/Slide7.JPG', 'path': 'stimuli/stim/Slide7.JPG'},
    {'name': 'stimuli/stim/Slide9.JPG', 'path': 'stimuli/stim/Slide9.JPG'},
    {'name': 'instructions.xlsx', 'path': 'instructions.xlsx'},
    {'name': 'stimuli/stim/Slide11.JPG', 'path': 'stimuli/stim/Slide11.JPG'}
  ]
});

psychoJS.experimentLogger.setLevel(core.Logger.ServerLevel.EXP);


var currentLoop;
var frameDur;
async function updateInfo() {
  currentLoop = psychoJS.experiment;  // right now there are no loops
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '2022.2.0';
  expInfo['OS'] = window.navigator.platform;

  psychoJS.experiment.dataFileName = (("." + "/") + `data/${expInfo["participant"]}_${expName}_${expInfo["date"]}`);

  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0 / Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0 / 60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  
  return Scheduler.Event.NEXT;
}


var instructionsClock;
var instr_image;
var instrmouse;
var scan_for_playersClock;
var instr_image_2;
var startClock;
var instr_image_3;
var instrmouse_2;
var trialClock;
var instr_image_4;
var a_votes;
var b_votes;
var c_votes;
var x_line;
var a_line;
var b_line;
var c_line;
var highlight;
var sound_1;
var xtext;
var atext;
var btext;
var ctext;
var text;
var respondClock;
var instr_image_5;
var a_votes_2;
var b_votes_2;
var c_votes_2;
var x_line_2;
var a_line_2;
var b_line_2;
var c_line_2;
var Abutton;
var Bbutton;
var Cbutton;
var xtext_2;
var atext_2;
var btext_2;
var ctext_2;
var text_2;
var endClock;
var instr_image_6;
var globalClock;
var routineTimer;
async function experimentInit() {
  // Initialize components for Routine "instructions"
  instructionsClock = new util.Clock();
  instr_image = new visual.ImageStim({
    win : psychoJS.window,
    name : 'instr_image', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0.0, pos : [0, 0], size : [1.6, 1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  instrmouse = new core.Mouse({
    win: psychoJS.window,
  });
  instrmouse.mouseClock = new util.Clock();
  // Initialize components for Routine "scan_for_players"
  scan_for_playersClock = new util.Clock();
  instr_image_2 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'instr_image_2', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0.0, pos : [0, 0], size : [1.6, 1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  // Initialize components for Routine "start"
  startClock = new util.Clock();
  instr_image_3 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'instr_image_3', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0.0, pos : [0, 0], size : [1.6, 1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  instrmouse_2 = new core.Mouse({
    win: psychoJS.window,
  });
  instrmouse_2.mouseClock = new util.Clock();
  // Initialize components for Routine "trial"
  trialClock = new util.Clock();
  instr_image_4 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'instr_image_4', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0.0, pos : [0, 0], size : [1.6, 1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  a_votes = new visual.TextStim({
    win: psychoJS.window,
    name: 'a_votes',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [(- 0.23), (- 0.05)], height: 0.02,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -2.0 
  });
  
  b_votes = new visual.TextStim({
    win: psychoJS.window,
    name: 'b_votes',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [(- 0.23), (- 0.1)], height: 0.02,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -3.0 
  });
  
  c_votes = new visual.TextStim({
    win: psychoJS.window,
    name: 'c_votes',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [(- 0.23), (- 0.15)], height: 0.02,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -4.0 
  });
  
  x_line = new visual.Rect ({
    win: psychoJS.window, name: 'x_line', 
    width: [1.0, 1.0][0], height: [1.0, 1.0][1],
    ori: 0.0, pos: [0, 0],
    lineWidth: 1.0, lineColor: new util.Color('black'),
    fillColor: new util.Color('black'),
    opacity: undefined, depth: -5, interpolate: true,
  });
  
  a_line = new visual.Rect ({
    win: psychoJS.window, name: 'a_line', 
    width: [1.0, 1.0][0], height: [1.0, 1.0][1],
    ori: 0.0, pos: [0, 0],
    lineWidth: 1.0, lineColor: new util.Color('black'),
    fillColor: new util.Color('black'),
    opacity: undefined, depth: -6, interpolate: true,
  });
  
  b_line = new visual.Rect ({
    win: psychoJS.window, name: 'b_line', 
    width: [1.0, 1.0][0], height: [1.0, 1.0][1],
    ori: 0.0, pos: [0, 0],
    lineWidth: 1.0, lineColor: new util.Color('black'),
    fillColor: new util.Color('black'),
    opacity: undefined, depth: -7, interpolate: true,
  });
  
  c_line = new visual.Rect ({
    win: psychoJS.window, name: 'c_line', 
    width: [1.0, 1.0][0], height: [1.0, 1.0][1],
    ori: 0.0, pos: [0, 0],
    lineWidth: 1.0, lineColor: new util.Color('black'),
    fillColor: new util.Color('black'),
    opacity: undefined, depth: -8, interpolate: true,
  });
  
  highlight = new visual.Rect ({
    win: psychoJS.window, name: 'highlight', 
    width: [0.1, 0.05][0], height: [0.1, 0.05][1],
    ori: 0.0, pos: [0, 0],
    lineWidth: 1.0, lineColor: new util.Color('#00ff00'),
    fillColor: new util.Color('#00ff00'),
    opacity: 0.3, depth: -9, interpolate: true,
  });
  
  sound_1 = new sound.Sound({
    win: psychoJS.window,
    value: 'A',
    secs: 0.1,
    });
  sound_1.setVolume(1.0);
  xtext = new visual.TextStim({
    win: psychoJS.window,
    name: 'xtext',
    text: 'X',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: -11.0 
  });
  
  atext = new visual.TextStim({
    win: psychoJS.window,
    name: 'atext',
    text: 'A',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: -12.0 
  });
  
  btext = new visual.TextStim({
    win: psychoJS.window,
    name: 'btext',
    text: 'B',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: -13.0 
  });
  
  ctext = new visual.TextStim({
    win: psychoJS.window,
    name: 'ctext',
    text: 'C',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: -14.0 
  });
  
  text = new visual.TextStim({
    win: psychoJS.window,
    name: 'text',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, (- 0.43)], height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('#ffff00'),  opacity: undefined,
    depth: -15.0 
  });
  
  // Initialize components for Routine "respond"
  respondClock = new util.Clock();
  instr_image_5 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'instr_image_5', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0.0, pos : [0, 0], size : [1.6, 1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  a_votes_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'a_votes_2',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [(- 0.23), (- 0.05)], height: 0.02,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -1.0 
  });
  
  b_votes_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'b_votes_2',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [(- 0.23), (- 0.1)], height: 0.02,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -2.0 
  });
  
  c_votes_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'c_votes_2',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [(- 0.23), (- 0.15)], height: 0.02,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('black'),  opacity: undefined,
    depth: -3.0 
  });
  
  x_line_2 = new visual.Rect ({
    win: psychoJS.window, name: 'x_line_2', 
    width: [1.0, 1.0][0], height: [1.0, 1.0][1],
    ori: 0.0, pos: [0, 0],
    lineWidth: 1.0, lineColor: new util.Color('black'),
    fillColor: new util.Color('black'),
    opacity: undefined, depth: -4, interpolate: true,
  });
  
  a_line_2 = new visual.Rect ({
    win: psychoJS.window, name: 'a_line_2', 
    width: [1.0, 1.0][0], height: [1.0, 1.0][1],
    ori: 0.0, pos: [0, 0],
    lineWidth: 1.0, lineColor: new util.Color('black'),
    fillColor: new util.Color('black'),
    opacity: undefined, depth: -5, interpolate: true,
  });
  
  b_line_2 = new visual.Rect ({
    win: psychoJS.window, name: 'b_line_2', 
    width: [1.0, 1.0][0], height: [1.0, 1.0][1],
    ori: 0.0, pos: [0, 0],
    lineWidth: 1.0, lineColor: new util.Color('black'),
    fillColor: new util.Color('black'),
    opacity: undefined, depth: -6, interpolate: true,
  });
  
  c_line_2 = new visual.Rect ({
    win: psychoJS.window, name: 'c_line_2', 
    width: [1.0, 1.0][0], height: [1.0, 1.0][1],
    ori: 0.0, pos: [0, 0],
    lineWidth: 1.0, lineColor: new util.Color('black'),
    fillColor: new util.Color('black'),
    opacity: undefined, depth: -7, interpolate: true,
  });
  
  Abutton = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'Abutton',
    text: 'A',
    fillColor: '#00ff00',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0.5, 0.05],
    letterHeight: 0.05,
    size: [0.2, 0.1]
  });
  Abutton.clock = new util.Clock();
  
  Bbutton = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'Bbutton',
    text: 'B',
    fillColor: '#00ff00',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0.5, (- 0.1)],
    letterHeight: 0.05,
    size: [0.2, 0.1]
  });
  Bbutton.clock = new util.Clock();
  
  Cbutton = new visual.ButtonStim({
    win: psychoJS.window,
    name: 'Cbutton',
    text: 'C',
    fillColor: '#00ff00',
    borderColor: null,
    color: 'white',
    colorSpace: 'rgb',
    pos: [0.5, (- 0.25)],
    letterHeight: 0.05,
    size: [0.2, 0.1]
  });
  Cbutton.clock = new util.Clock();
  
  xtext_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'xtext_2',
    text: 'X',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: -11.0 
  });
  
  atext_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'atext_2',
    text: 'A',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: -12.0 
  });
  
  btext_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'btext_2',
    text: 'B',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: -13.0 
  });
  
  ctext_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'ctext_2',
    text: 'C',
    font: 'Open Sans',
    units: undefined, 
    pos: [0, 0], height: 0.05,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: -14.0 
  });
  
  text_2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_2',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, (- 0.43)], height: 0.04,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('#ffff00'),  opacity: undefined,
    depth: -15.0 
  });
  
  // Initialize components for Routine "end"
  endClock = new util.Clock();
  instr_image_6 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'instr_image_6', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0.0, pos : [0, 0], size : [1.6, 1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}


var instr;
function instrLoopBegin(instrLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    instr = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'instructions.xlsx',
      seed: undefined, name: 'instr'
    });
    psychoJS.experiment.addLoop(instr); // add the loop to the experiment
    currentLoop = instr;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisInstr of instr) {
      snapshot = instr.getSnapshot();
      instrLoopScheduler.add(importConditions(snapshot));
      instrLoopScheduler.add(instructionsRoutineBegin(snapshot));
      instrLoopScheduler.add(instructionsRoutineEachFrame());
      instrLoopScheduler.add(instructionsRoutineEnd(snapshot));
      instrLoopScheduler.add(instrLoopEndIteration(instrLoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function instrLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(instr);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function instrLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var scan;
function scanLoopBegin(scanLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    scan = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 5, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'scanning.xlsx',
      seed: undefined, name: 'scan'
    });
    psychoJS.experiment.addLoop(scan); // add the loop to the experiment
    currentLoop = scan;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisScan of scan) {
      snapshot = scan.getSnapshot();
      scanLoopScheduler.add(importConditions(snapshot));
      scanLoopScheduler.add(scan_for_playersRoutineBegin(snapshot));
      scanLoopScheduler.add(scan_for_playersRoutineEachFrame());
      scanLoopScheduler.add(scan_for_playersRoutineEnd(snapshot));
      scanLoopScheduler.add(scanLoopEndIteration(scanLoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function scanLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(scan);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function scanLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials;
function trialsLoopBegin(trialsLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'trials.xlsx',
      seed: undefined, name: 'trials'
    });
    psychoJS.experiment.addLoop(trials); // add the loop to the experiment
    currentLoop = trials;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisTrial of trials) {
      snapshot = trials.getSnapshot();
      trialsLoopScheduler.add(importConditions(snapshot));
      const votesLoopScheduler = new Scheduler(psychoJS);
      trialsLoopScheduler.add(votesLoopBegin(votesLoopScheduler, snapshot));
      trialsLoopScheduler.add(votesLoopScheduler);
      trialsLoopScheduler.add(votesLoopEnd);
      trialsLoopScheduler.add(respondRoutineBegin(snapshot));
      trialsLoopScheduler.add(respondRoutineEachFrame());
      trialsLoopScheduler.add(respondRoutineEnd(snapshot));
      trialsLoopScheduler.add(trialsLoopEndIteration(trialsLoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


var votes;
function votesLoopBegin(votesLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    votes = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 5, method: TrialHandler.Method.RANDOM,
      extraInfo: expInfo, originPath: undefined,
      trialList: undefined,
      seed: undefined, name: 'votes'
    });
    psychoJS.experiment.addLoop(votes); // add the loop to the experiment
    currentLoop = votes;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisVote of votes) {
      snapshot = votes.getSnapshot();
      votesLoopScheduler.add(importConditions(snapshot));
      votesLoopScheduler.add(trialRoutineBegin(snapshot));
      votesLoopScheduler.add(trialRoutineEachFrame());
      votesLoopScheduler.add(trialRoutineEnd(snapshot));
      votesLoopScheduler.add(votesLoopEndIteration(votesLoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function votesLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(votes);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function votesLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


async function trialsLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trialsLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var t;
var frameN;
var continueRoutine;
var gotValidClick;
var instructionsComponents;
function instructionsRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'instructions' ---
    t = 0;
    instructionsClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    instr_image.setImage(thisSlide);
    // setup some python lists for storing info about the instrmouse
    // current position of the mouse:
    instrmouse.x = [];
    instrmouse.y = [];
    instrmouse.leftButton = [];
    instrmouse.midButton = [];
    instrmouse.rightButton = [];
    instrmouse.time = [];
    gotValidClick = false; // until a click is received
    // keep track of which components have finished
    instructionsComponents = [];
    instructionsComponents.push(instr_image);
    instructionsComponents.push(instrmouse);
    
    for (const thisComponent of instructionsComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


var prevButtonState;
var _mouseButtons;
var _mouseXYs;
function instructionsRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'instructions' ---
    // get current time
    t = instructionsClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *instr_image* updates
    if (t >= 0.0 && instr_image.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instr_image.tStart = t;  // (not accounting for frame time here)
      instr_image.frameNStart = frameN;  // exact frame index
      
      instr_image.setAutoDraw(true);
    }

    // *instrmouse* updates
    if (t >= 0.0 && instrmouse.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instrmouse.tStart = t;  // (not accounting for frame time here)
      instrmouse.frameNStart = frameN;  // exact frame index
      
      instrmouse.status = PsychoJS.Status.STARTED;
      instrmouse.mouseClock.reset();
      prevButtonState = instrmouse.getPressed();  // if button is down already this ISN'T a new click
      }
    if (instrmouse.status === PsychoJS.Status.STARTED) {  // only update if started and not finished!
      _mouseButtons = instrmouse.getPressed();
      if (!_mouseButtons.every( (e,i,) => (e == prevButtonState[i]) )) { // button state changed?
        prevButtonState = _mouseButtons;
        if (_mouseButtons.reduce( (e, acc) => (e+acc) ) > 0) { // state changed to a new click
          _mouseXYs = instrmouse.getPos();
          instrmouse.x.push(_mouseXYs[0]);
          instrmouse.y.push(_mouseXYs[1]);
          instrmouse.leftButton.push(_mouseButtons[0]);
          instrmouse.midButton.push(_mouseButtons[1]);
          instrmouse.rightButton.push(_mouseButtons[2]);
          instrmouse.time.push(instrmouse.mouseClock.getTime());
          // abort routine on response
          continueRoutine = false;
        }
      }
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of instructionsComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function instructionsRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'instructions' ---
    for (const thisComponent of instructionsComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // store data for psychoJS.experiment (ExperimentHandler)
    if (instrmouse.x) {  psychoJS.experiment.addData('instrmouse.x', instrmouse.x[0])};
    if (instrmouse.y) {  psychoJS.experiment.addData('instrmouse.y', instrmouse.y[0])};
    if (instrmouse.leftButton) {  psychoJS.experiment.addData('instrmouse.leftButton', instrmouse.leftButton[0])};
    if (instrmouse.midButton) {  psychoJS.experiment.addData('instrmouse.midButton', instrmouse.midButton[0])};
    if (instrmouse.rightButton) {  psychoJS.experiment.addData('instrmouse.rightButton', instrmouse.rightButton[0])};
    if (instrmouse.time) {  psychoJS.experiment.addData('instrmouse.time', instrmouse.time[0])};
    
    // the Routine "instructions" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var scan_for_playersComponents;
function scan_for_playersRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'scan_for_players' ---
    t = 0;
    scan_for_playersClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(0.500000);
    // update component parameters for each repeat
    instr_image_2.setImage(thisSlide);
    // keep track of which components have finished
    scan_for_playersComponents = [];
    scan_for_playersComponents.push(instr_image_2);
    
    for (const thisComponent of scan_for_playersComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


var frameRemains;
function scan_for_playersRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'scan_for_players' ---
    // get current time
    t = scan_for_playersClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *instr_image_2* updates
    if (t >= 0.0 && instr_image_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instr_image_2.tStart = t;  // (not accounting for frame time here)
      instr_image_2.frameNStart = frameN;  // exact frame index
      
      instr_image_2.setAutoDraw(true);
    }

    frameRemains = 0.0 + 0.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (instr_image_2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      instr_image_2.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of scan_for_playersComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function scan_for_playersRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'scan_for_players' ---
    for (const thisComponent of scan_for_playersComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var startComponents;
function startRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'start' ---
    t = 0;
    startClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    instr_image_3.setImage('stimuli/stim/Slide8.JPG');
    // setup some python lists for storing info about the instrmouse_2
    // current position of the mouse:
    instrmouse_2.x = [];
    instrmouse_2.y = [];
    instrmouse_2.leftButton = [];
    instrmouse_2.midButton = [];
    instrmouse_2.rightButton = [];
    instrmouse_2.time = [];
    gotValidClick = false; // until a click is received
    // keep track of which components have finished
    startComponents = [];
    startComponents.push(instr_image_3);
    startComponents.push(instrmouse_2);
    
    for (const thisComponent of startComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function startRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'start' ---
    // get current time
    t = startClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *instr_image_3* updates
    if (t >= 0.0 && instr_image_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instr_image_3.tStart = t;  // (not accounting for frame time here)
      instr_image_3.frameNStart = frameN;  // exact frame index
      
      instr_image_3.setAutoDraw(true);
    }

    // *instrmouse_2* updates
    if (t >= 0.0 && instrmouse_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instrmouse_2.tStart = t;  // (not accounting for frame time here)
      instrmouse_2.frameNStart = frameN;  // exact frame index
      
      instrmouse_2.status = PsychoJS.Status.STARTED;
      instrmouse_2.mouseClock.reset();
      prevButtonState = instrmouse_2.getPressed();  // if button is down already this ISN'T a new click
      }
    if (instrmouse_2.status === PsychoJS.Status.STARTED) {  // only update if started and not finished!
      _mouseButtons = instrmouse_2.getPressed();
      if (!_mouseButtons.every( (e,i,) => (e == prevButtonState[i]) )) { // button state changed?
        prevButtonState = _mouseButtons;
        if (_mouseButtons.reduce( (e, acc) => (e+acc) ) > 0) { // state changed to a new click
          _mouseXYs = instrmouse_2.getPos();
          instrmouse_2.x.push(_mouseXYs[0]);
          instrmouse_2.y.push(_mouseXYs[1]);
          instrmouse_2.leftButton.push(_mouseButtons[0]);
          instrmouse_2.midButton.push(_mouseButtons[1]);
          instrmouse_2.rightButton.push(_mouseButtons[2]);
          instrmouse_2.time.push(instrmouse_2.mouseClock.getTime());
          // abort routine on response
          continueRoutine = false;
        }
      }
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of startComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function startRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'start' ---
    for (const thisComponent of startComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // store data for psychoJS.experiment (ExperimentHandler)
    if (instrmouse_2.x) {  psychoJS.experiment.addData('instrmouse_2.x', instrmouse_2.x[0])};
    if (instrmouse_2.y) {  psychoJS.experiment.addData('instrmouse_2.y', instrmouse_2.y[0])};
    if (instrmouse_2.leftButton) {  psychoJS.experiment.addData('instrmouse_2.leftButton', instrmouse_2.leftButton[0])};
    if (instrmouse_2.midButton) {  psychoJS.experiment.addData('instrmouse_2.midButton', instrmouse_2.midButton[0])};
    if (instrmouse_2.rightButton) {  psychoJS.experiment.addData('instrmouse_2.rightButton', instrmouse_2.rightButton[0])};
    if (instrmouse_2.time) {  psychoJS.experiment.addData('instrmouse_2.time', instrmouse_2.time[0])};
    
    // the Routine "start" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var n_a_votes;
var n_b_votes;
var n_c_votes;
var liney;
var highlight_x;
var highlight_y;
var interval;
var trialComponents;
function trialRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'trial' ---
    t = 0;
    trialClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    // Run 'Begin Routine' code from code
    n_a_votes = 0;
    n_b_votes = 0;
    n_c_votes = 0;
    liney = (- 0.25);
    if ((team_vote === "A")) {
        n_a_votes = (votes.thisN + 1);
        highlight_x = a_votes.pos[0];
        highlight_y = a_votes.pos[1];
    }
    if ((team_vote === "B")) {
        n_b_votes = (votes.thisN + 1);
        highlight_x = b_votes.pos[0];
        highlight_y = b_votes.pos[1];
    }
    if ((team_vote === "C")) {
        n_c_votes = (votes.thisN + 1);
        highlight_x = c_votes.pos[0];
        highlight_y = c_votes.pos[1];
    }
    interval = (((1 + Math.random()) + Math.random()) + Math.random());
    
    instr_image_4.setImage('stimuli/stim/Slide9.JPG');
    a_votes.setText(n_a_votes);
    b_votes.setText(n_b_votes);
    c_votes.setText(n_c_votes);
    x_line.setPos([(- 0.03), (liney + (x_length / 2))]);
    x_line.setSize([0.01, x_length]);
    a_line.setPos([0.1, (liney + (a_length / 2))]);
    a_line.setSize([0.01, a_length]);
    b_line.setPos([0.2, (liney + (b_length / 2))]);
    b_line.setSize([0.01, b_length]);
    c_line.setPos([0.3, (liney + (c_length / 2))]);
    c_line.setSize([0.01, c_length]);
    highlight.setPos([highlight_x, highlight_y]);
    sound_1.secs=0.1;
    sound_1.setVolume(1.0);
    xtext.setPos([x_line.pos[0], (- 0.3)]);
    atext.setPos([a_line.pos[0], (- 0.3)]);
    btext.setPos([b_line.pos[0], (- 0.3)]);
    ctext.setPos([c_line.pos[0], (- 0.3)]);
    text.setText((("Trial number " + (trials.thisN + 1).toString()) + "/18"));
    // keep track of which components have finished
    trialComponents = [];
    trialComponents.push(instr_image_4);
    trialComponents.push(a_votes);
    trialComponents.push(b_votes);
    trialComponents.push(c_votes);
    trialComponents.push(x_line);
    trialComponents.push(a_line);
    trialComponents.push(b_line);
    trialComponents.push(c_line);
    trialComponents.push(highlight);
    trialComponents.push(sound_1);
    trialComponents.push(xtext);
    trialComponents.push(atext);
    trialComponents.push(btext);
    trialComponents.push(ctext);
    trialComponents.push(text);
    
    for (const thisComponent of trialComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function trialRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'trial' ---
    // get current time
    t = trialClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // Run 'Each Frame' code from code
    if ((t > interval)) {
        continueRoutine = false;
    }
    
    
    // *instr_image_4* updates
    if (t >= 0.0 && instr_image_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instr_image_4.tStart = t;  // (not accounting for frame time here)
      instr_image_4.frameNStart = frameN;  // exact frame index
      
      instr_image_4.setAutoDraw(true);
    }

    
    // *a_votes* updates
    if (t >= 0.0 && a_votes.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      a_votes.tStart = t;  // (not accounting for frame time here)
      a_votes.frameNStart = frameN;  // exact frame index
      
      a_votes.setAutoDraw(true);
    }

    
    // *b_votes* updates
    if (t >= 0.0 && b_votes.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      b_votes.tStart = t;  // (not accounting for frame time here)
      b_votes.frameNStart = frameN;  // exact frame index
      
      b_votes.setAutoDraw(true);
    }

    
    // *c_votes* updates
    if (t >= 0.0 && c_votes.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      c_votes.tStart = t;  // (not accounting for frame time here)
      c_votes.frameNStart = frameN;  // exact frame index
      
      c_votes.setAutoDraw(true);
    }

    
    // *x_line* updates
    if (t >= 0.0 && x_line.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      x_line.tStart = t;  // (not accounting for frame time here)
      x_line.frameNStart = frameN;  // exact frame index
      
      x_line.setAutoDraw(true);
    }

    
    // *a_line* updates
    if (t >= 0.0 && a_line.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      a_line.tStart = t;  // (not accounting for frame time here)
      a_line.frameNStart = frameN;  // exact frame index
      
      a_line.setAutoDraw(true);
    }

    
    // *b_line* updates
    if (t >= 0.0 && b_line.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      b_line.tStart = t;  // (not accounting for frame time here)
      b_line.frameNStart = frameN;  // exact frame index
      
      b_line.setAutoDraw(true);
    }

    
    // *c_line* updates
    if (t >= 0.0 && c_line.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      c_line.tStart = t;  // (not accounting for frame time here)
      c_line.frameNStart = frameN;  // exact frame index
      
      c_line.setAutoDraw(true);
    }

    
    // *highlight* updates
    if (t >= 0 && highlight.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      highlight.tStart = t;  // (not accounting for frame time here)
      highlight.frameNStart = frameN;  // exact frame index
      
      highlight.setAutoDraw(true);
    }

    frameRemains = 0 + 0.1 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (highlight.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      highlight.setAutoDraw(false);
    }
    // start/stop sound_1
    if (t >= 0.0 && sound_1.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      sound_1.tStart = t;  // (not accounting for frame time here)
      sound_1.frameNStart = frameN;  // exact frame index
      
      psychoJS.window.callOnFlip(function(){ sound_1.play(); });  // screen flip
      sound_1.status = PsychoJS.Status.STARTED;
    }
    frameRemains = 0.0 + 0.1 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (sound_1.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      if (0.1 > 0.5) {
        sound_1.stop();  // stop the sound (if longer than duration)
      }
      sound_1.status = PsychoJS.Status.FINISHED;
    }
    
    // *xtext* updates
    if (t >= 0.0 && xtext.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      xtext.tStart = t;  // (not accounting for frame time here)
      xtext.frameNStart = frameN;  // exact frame index
      
      xtext.setAutoDraw(true);
    }

    
    // *atext* updates
    if (t >= 0.0 && atext.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      atext.tStart = t;  // (not accounting for frame time here)
      atext.frameNStart = frameN;  // exact frame index
      
      atext.setAutoDraw(true);
    }

    
    // *btext* updates
    if (t >= 0.0 && btext.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      btext.tStart = t;  // (not accounting for frame time here)
      btext.frameNStart = frameN;  // exact frame index
      
      btext.setAutoDraw(true);
    }

    
    // *ctext* updates
    if (t >= 0.0 && ctext.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ctext.tStart = t;  // (not accounting for frame time here)
      ctext.frameNStart = frameN;  // exact frame index
      
      ctext.setAutoDraw(true);
    }

    
    // *text* updates
    if (t >= 0.0 && text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text.tStart = t;  // (not accounting for frame time here)
      text.frameNStart = frameN;  // exact frame index
      
      text.setAutoDraw(true);
    }

    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of trialComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function trialRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'trial' ---
    for (const thisComponent of trialComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    sound_1.stop();  // ensure sound has stopped at end of routine
    // the Routine "trial" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var respondComponents;
function respondRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'respond' ---
    t = 0;
    respondClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    instr_image_5.setImage('stimuli/stim/Slide10.JPG');
    a_votes_2.setText(n_a_votes);
    b_votes_2.setText(n_b_votes);
    c_votes_2.setText(n_c_votes);
    x_line_2.setPos([(- 0.03), (liney + (x_length / 2))]);
    x_line_2.setSize([0.01, x_length]);
    a_line_2.setPos([0.1, (liney + (a_length / 2))]);
    a_line_2.setSize([0.01, a_length]);
    b_line_2.setPos([0.2, (liney + (b_length / 2))]);
    b_line_2.setSize([0.01, b_length]);
    c_line_2.setPos([0.3, (liney + (c_length / 2))]);
    c_line_2.setSize([0.01, c_length]);
    xtext_2.setPos([x_line.pos[0], (- 0.3)]);
    atext_2.setPos([a_line.pos[0], (- 0.3)]);
    btext_2.setPos([b_line.pos[0], (- 0.3)]);
    ctext_2.setPos([c_line.pos[0], (- 0.3)]);
    text_2.setText((("Trial number " + (trials.thisN + 1).toString()) + "/18"));
    // keep track of which components have finished
    respondComponents = [];
    respondComponents.push(instr_image_5);
    respondComponents.push(a_votes_2);
    respondComponents.push(b_votes_2);
    respondComponents.push(c_votes_2);
    respondComponents.push(x_line_2);
    respondComponents.push(a_line_2);
    respondComponents.push(b_line_2);
    respondComponents.push(c_line_2);
    respondComponents.push(Abutton);
    respondComponents.push(Bbutton);
    respondComponents.push(Cbutton);
    respondComponents.push(xtext_2);
    respondComponents.push(atext_2);
    respondComponents.push(btext_2);
    respondComponents.push(ctext_2);
    respondComponents.push(text_2);
    
    for (const thisComponent of respondComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function respondRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'respond' ---
    // get current time
    t = respondClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *instr_image_5* updates
    if (t >= 0.0 && instr_image_5.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instr_image_5.tStart = t;  // (not accounting for frame time here)
      instr_image_5.frameNStart = frameN;  // exact frame index
      
      instr_image_5.setAutoDraw(true);
    }

    
    // *a_votes_2* updates
    if (t >= 0.0 && a_votes_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      a_votes_2.tStart = t;  // (not accounting for frame time here)
      a_votes_2.frameNStart = frameN;  // exact frame index
      
      a_votes_2.setAutoDraw(true);
    }

    
    // *b_votes_2* updates
    if (t >= 0.0 && b_votes_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      b_votes_2.tStart = t;  // (not accounting for frame time here)
      b_votes_2.frameNStart = frameN;  // exact frame index
      
      b_votes_2.setAutoDraw(true);
    }

    
    // *c_votes_2* updates
    if (t >= 0.0 && c_votes_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      c_votes_2.tStart = t;  // (not accounting for frame time here)
      c_votes_2.frameNStart = frameN;  // exact frame index
      
      c_votes_2.setAutoDraw(true);
    }

    
    // *x_line_2* updates
    if (t >= 0.0 && x_line_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      x_line_2.tStart = t;  // (not accounting for frame time here)
      x_line_2.frameNStart = frameN;  // exact frame index
      
      x_line_2.setAutoDraw(true);
    }

    
    // *a_line_2* updates
    if (t >= 0.0 && a_line_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      a_line_2.tStart = t;  // (not accounting for frame time here)
      a_line_2.frameNStart = frameN;  // exact frame index
      
      a_line_2.setAutoDraw(true);
    }

    
    // *b_line_2* updates
    if (t >= 0.0 && b_line_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      b_line_2.tStart = t;  // (not accounting for frame time here)
      b_line_2.frameNStart = frameN;  // exact frame index
      
      b_line_2.setAutoDraw(true);
    }

    
    // *c_line_2* updates
    if (t >= 0.0 && c_line_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      c_line_2.tStart = t;  // (not accounting for frame time here)
      c_line_2.frameNStart = frameN;  // exact frame index
      
      c_line_2.setAutoDraw(true);
    }

    
    // *Abutton* updates
    if (t >= 0 && Abutton.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Abutton.tStart = t;  // (not accounting for frame time here)
      Abutton.frameNStart = frameN;  // exact frame index
      
      Abutton.setAutoDraw(true);
    }

    if (Abutton.status === PsychoJS.Status.STARTED) {
      // check whether Abutton has been pressed
      if (Abutton.isClicked) {
        if (!Abutton.wasClicked) {
          // store time of first click
          Abutton.timesOn.push(Abutton.clock.getTime());
          Abutton.numClicks += 1;
          // store time clicked until
          Abutton.timesOff.push(Abutton.clock.getTime());
        } else {
          // update time clicked until;
          Abutton.timesOff[Abutton.timesOff.length - 1] = Abutton.clock.getTime();
        }
        if (!Abutton.wasClicked) {
          // end routine when Abutton is clicked
          continueRoutine = false;
        }
        // if Abutton is still clicked next frame, it is not a new click
        Abutton.wasClicked = true;
      } else {
        // if Abutton is clicked next frame, it is a new click
        Abutton.wasClicked = false;
      }
    } else {
      // keep clock at 0 if Abutton hasn't started / has finished
      Abutton.clock.reset();
      // if Abutton is clicked next frame, it is a new click
      Abutton.wasClicked = false;
    }
    
    // *Bbutton* updates
    if (t >= 0 && Bbutton.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Bbutton.tStart = t;  // (not accounting for frame time here)
      Bbutton.frameNStart = frameN;  // exact frame index
      
      Bbutton.setAutoDraw(true);
    }

    if (Bbutton.status === PsychoJS.Status.STARTED) {
      // check whether Bbutton has been pressed
      if (Bbutton.isClicked) {
        if (!Bbutton.wasClicked) {
          // store time of first click
          Bbutton.timesOn.push(Bbutton.clock.getTime());
          Bbutton.numClicks += 1;
          // store time clicked until
          Bbutton.timesOff.push(Bbutton.clock.getTime());
        } else {
          // update time clicked until;
          Bbutton.timesOff[Bbutton.timesOff.length - 1] = Bbutton.clock.getTime();
        }
        if (!Bbutton.wasClicked) {
          // end routine when Bbutton is clicked
          continueRoutine = false;
        }
        // if Bbutton is still clicked next frame, it is not a new click
        Bbutton.wasClicked = true;
      } else {
        // if Bbutton is clicked next frame, it is a new click
        Bbutton.wasClicked = false;
      }
    } else {
      // keep clock at 0 if Bbutton hasn't started / has finished
      Bbutton.clock.reset();
      // if Bbutton is clicked next frame, it is a new click
      Bbutton.wasClicked = false;
    }
    
    // *Cbutton* updates
    if (t >= 0 && Cbutton.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      Cbutton.tStart = t;  // (not accounting for frame time here)
      Cbutton.frameNStart = frameN;  // exact frame index
      
      Cbutton.setAutoDraw(true);
    }

    if (Cbutton.status === PsychoJS.Status.STARTED) {
      // check whether Cbutton has been pressed
      if (Cbutton.isClicked) {
        if (!Cbutton.wasClicked) {
          // store time of first click
          Cbutton.timesOn.push(Cbutton.clock.getTime());
          Cbutton.numClicks += 1;
          // store time clicked until
          Cbutton.timesOff.push(Cbutton.clock.getTime());
        } else {
          // update time clicked until;
          Cbutton.timesOff[Cbutton.timesOff.length - 1] = Cbutton.clock.getTime();
        }
        if (!Cbutton.wasClicked) {
          // end routine when Cbutton is clicked
          continueRoutine = false;
        }
        // if Cbutton is still clicked next frame, it is not a new click
        Cbutton.wasClicked = true;
      } else {
        // if Cbutton is clicked next frame, it is a new click
        Cbutton.wasClicked = false;
      }
    } else {
      // keep clock at 0 if Cbutton hasn't started / has finished
      Cbutton.clock.reset();
      // if Cbutton is clicked next frame, it is a new click
      Cbutton.wasClicked = false;
    }
    
    // *xtext_2* updates
    if (t >= 0.0 && xtext_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      xtext_2.tStart = t;  // (not accounting for frame time here)
      xtext_2.frameNStart = frameN;  // exact frame index
      
      xtext_2.setAutoDraw(true);
    }

    
    // *atext_2* updates
    if (t >= 0.0 && atext_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      atext_2.tStart = t;  // (not accounting for frame time here)
      atext_2.frameNStart = frameN;  // exact frame index
      
      atext_2.setAutoDraw(true);
    }

    
    // *btext_2* updates
    if (t >= 0.0 && btext_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      btext_2.tStart = t;  // (not accounting for frame time here)
      btext_2.frameNStart = frameN;  // exact frame index
      
      btext_2.setAutoDraw(true);
    }

    
    // *ctext_2* updates
    if (t >= 0.0 && ctext_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ctext_2.tStart = t;  // (not accounting for frame time here)
      ctext_2.frameNStart = frameN;  // exact frame index
      
      ctext_2.setAutoDraw(true);
    }

    
    // *text_2* updates
    if (t >= 0.0 && text_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text_2.tStart = t;  // (not accounting for frame time here)
      text_2.frameNStart = frameN;  // exact frame index
      
      text_2.setAutoDraw(true);
    }

    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of respondComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function respondRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'respond' ---
    for (const thisComponent of respondComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    psychoJS.experiment.addData('Abutton.numClicks', Abutton.numClicks);
    psychoJS.experiment.addData('Abutton.timesOn', Abutton.timesOn);
    psychoJS.experiment.addData('Abutton.timesOff', Abutton.timesOff);
    psychoJS.experiment.addData('Bbutton.numClicks', Bbutton.numClicks);
    psychoJS.experiment.addData('Bbutton.timesOn', Bbutton.timesOn);
    psychoJS.experiment.addData('Bbutton.timesOff', Bbutton.timesOff);
    psychoJS.experiment.addData('Cbutton.numClicks', Cbutton.numClicks);
    psychoJS.experiment.addData('Cbutton.timesOn', Cbutton.timesOn);
    psychoJS.experiment.addData('Cbutton.timesOff', Cbutton.timesOff);
    // the Routine "respond" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var endComponents;
function endRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'end' ---
    t = 0;
    endClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(2.000000);
    // update component parameters for each repeat
    instr_image_6.setImage('stimuli/stim/Slide11.JPG');
    // keep track of which components have finished
    endComponents = [];
    endComponents.push(instr_image_6);
    
    for (const thisComponent of endComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function endRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'end' ---
    // get current time
    t = endClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *instr_image_6* updates
    if (t >= 0.0 && instr_image_6.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      instr_image_6.tStart = t;  // (not accounting for frame time here)
      instr_image_6.frameNStart = frameN;  // exact frame index
      
      instr_image_6.setAutoDraw(true);
    }

    frameRemains = 0.0 + 2 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (instr_image_6.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      instr_image_6.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of endComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function endRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'end' ---
    for (const thisComponent of endComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


function importConditions(currentLoop) {
  return async function () {
    psychoJS.importAttributes(currentLoop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


async function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (psychoJS.experiment.isEntryEmpty()) {
    psychoJS.experiment.nextEntry();
  }
  
  
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});
  
  return Scheduler.Event.QUIT;
}

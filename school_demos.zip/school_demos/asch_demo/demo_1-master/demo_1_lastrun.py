﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2022.2.0),
    on July 08, 2022, at 11:49
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)
# Store info about the experiment session
psychopyVersion = '2022.2.0'
expName = 'demo_1'  # from the Builder filename that created this script
expInfo = {
    'participant': '',
    'session': '001',
}
# --- Show participant info dialog --
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='G:\\Shared drives\\Science\\Schools\\demos\\demo_1\\demo_1_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# --- Setup the Window ---
win = visual.Window(
    size=(1024, 768), fullscr=True, screen=0, 
    winType='pyglet', allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
win.mouseVisible = False
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess
# --- Setup input devices ---
ioConfig = {}

# Setup iohub keyboard
ioConfig['Keyboard'] = dict(use_keymap='psychopy')

ioSession = '1'
if 'session' in expInfo:
    ioSession = str(expInfo['session'])
ioServer = io.launchHubServer(window=win, **ioConfig)
eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard(backend='iohub')

# --- Initialize components for Routine "instructions" ---
instr_image = visual.ImageStim(
    win=win,
    name='instr_image', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(1.6, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
instrmouse = event.Mouse(win=win)
x, y = [None, None]
instrmouse.mouseClock = core.Clock()

# --- Initialize components for Routine "scan_for_players" ---
instr_image_2 = visual.ImageStim(
    win=win,
    name='instr_image_2', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(1.6, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)

# --- Initialize components for Routine "start" ---
instr_image_3 = visual.ImageStim(
    win=win,
    name='instr_image_3', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(1.6, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
instrmouse_2 = event.Mouse(win=win)
x, y = [None, None]
instrmouse_2.mouseClock = core.Clock()

# --- Initialize components for Routine "trial" ---
instr_image_4 = visual.ImageStim(
    win=win,
    name='instr_image_4', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(1.6, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)
a_votes = visual.TextStim(win=win, name='a_votes',
    text='',
    font='Arial',
    pos=(-0.23, -0.05), height=0.02, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
b_votes = visual.TextStim(win=win, name='b_votes',
    text='',
    font='Arial',
    pos=(-0.23, -0.1), height=0.02, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);
c_votes = visual.TextStim(win=win, name='c_votes',
    text='',
    font='Arial',
    pos=(-0.23, -0.15), height=0.02, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-4.0);
x_line = visual.Rect(
    win=win, name='x_line',
    width=[1.0, 1.0][0], height=[1.0, 1.0][1],
    ori=0.0, pos=[0,0], anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor='black', fillColor='black',
    opacity=None, depth=-5.0, interpolate=True)
a_line = visual.Rect(
    win=win, name='a_line',
    width=[1.0, 1.0][0], height=[1.0, 1.0][1],
    ori=0.0, pos=[0,0], anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor='black', fillColor='black',
    opacity=None, depth=-6.0, interpolate=True)
b_line = visual.Rect(
    win=win, name='b_line',
    width=[1.0, 1.0][0], height=[1.0, 1.0][1],
    ori=0.0, pos=[0,0], anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor='black', fillColor='black',
    opacity=None, depth=-7.0, interpolate=True)
c_line = visual.Rect(
    win=win, name='c_line',
    width=[1.0, 1.0][0], height=[1.0, 1.0][1],
    ori=0.0, pos=[0,0], anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor='black', fillColor='black',
    opacity=None, depth=-8.0, interpolate=True)
highlight = visual.Rect(
    win=win, name='highlight',
    width=(0.1, 0.05)[0], height=(0.1, 0.05)[1],
    ori=0.0, pos=[0,0], anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor='#00ff00', fillColor='#00ff00',
    opacity=0.3, depth=-9.0, interpolate=True)
sound_1 = sound.Sound('A', secs=0.1, stereo=True, hamming=True,
    name='sound_1')
sound_1.setVolume(1.0)
xtext = visual.TextStim(win=win, name='xtext',
    text='X',
    font='Open Sans',
    pos=[0,0], height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-11.0);
atext = visual.TextStim(win=win, name='atext',
    text='A',
    font='Open Sans',
    pos=[0,0], height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-12.0);
btext = visual.TextStim(win=win, name='btext',
    text='B',
    font='Open Sans',
    pos=[0,0], height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-13.0);
ctext = visual.TextStim(win=win, name='ctext',
    text='C',
    font='Open Sans',
    pos=[0,0], height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-14.0);

# --- Initialize components for Routine "respond" ---
instr_image_5 = visual.ImageStim(
    win=win,
    name='instr_image_5', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(1.6, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
a_votes_2 = visual.TextStim(win=win, name='a_votes_2',
    text='',
    font='Arial',
    pos=(-0.23, -0.05), height=0.02, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
b_votes_2 = visual.TextStim(win=win, name='b_votes_2',
    text='',
    font='Arial',
    pos=(-0.23, -0.1), height=0.02, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-2.0);
c_votes_2 = visual.TextStim(win=win, name='c_votes_2',
    text='',
    font='Arial',
    pos=(-0.23, -0.15), height=0.02, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-3.0);
x_line_2 = visual.Rect(
    win=win, name='x_line_2',
    width=[1.0, 1.0][0], height=[1.0, 1.0][1],
    ori=0.0, pos=[0,0], anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor='black', fillColor='black',
    opacity=None, depth=-4.0, interpolate=True)
a_line_2 = visual.Rect(
    win=win, name='a_line_2',
    width=[1.0, 1.0][0], height=[1.0, 1.0][1],
    ori=0.0, pos=[0,0], anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor='black', fillColor='black',
    opacity=None, depth=-5.0, interpolate=True)
b_line_2 = visual.Rect(
    win=win, name='b_line_2',
    width=[1.0, 1.0][0], height=[1.0, 1.0][1],
    ori=0.0, pos=[0,0], anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor='black', fillColor='black',
    opacity=None, depth=-6.0, interpolate=True)
c_line_2 = visual.Rect(
    win=win, name='c_line_2',
    width=[1.0, 1.0][0], height=[1.0, 1.0][1],
    ori=0.0, pos=[0,0], anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor='black', fillColor='black',
    opacity=None, depth=-7.0, interpolate=True)
Abutton = visual.ButtonStim(win, 
    text='A', font='Arvo',
    pos=(0.5, 0.1),
    letterHeight=0.05,
    size=(0.2, 0.1), borderWidth=0.0,
    fillColor='#00ff00', borderColor=None,
    color='white', colorSpace='rgb',
    opacity=None,
    bold=True, italic=False,
    padding=None,
    anchor='center',
    name='Abutton'
)
Abutton.buttonClock = core.Clock()
Bbutton = visual.ButtonStim(win, 
    text='B', font='Arvo',
    pos=(0.5, -0.1),
    letterHeight=0.05,
    size=(0.2, 0.1), borderWidth=0.0,
    fillColor='#00ff00', borderColor=None,
    color='white', colorSpace='rgb',
    opacity=None,
    bold=True, italic=False,
    padding=None,
    anchor='center',
    name='Bbutton'
)
Bbutton.buttonClock = core.Clock()
Cbutton = visual.ButtonStim(win, 
    text='C', font='Arvo',
    pos=(0.5, -0.3),
    letterHeight=0.05,
    size=(0.2, 0.1), borderWidth=0.0,
    fillColor='#00ff00', borderColor=None,
    color='white', colorSpace='rgb',
    opacity=None,
    bold=True, italic=False,
    padding=None,
    anchor='center',
    name='Cbutton'
)
Cbutton.buttonClock = core.Clock()
xtext_2 = visual.TextStim(win=win, name='xtext_2',
    text='X',
    font='Open Sans',
    pos=[0,0], height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-11.0);
atext_2 = visual.TextStim(win=win, name='atext_2',
    text='A',
    font='Open Sans',
    pos=[0,0], height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-12.0);
btext_2 = visual.TextStim(win=win, name='btext_2',
    text='B',
    font='Open Sans',
    pos=[0,0], height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-13.0);
ctext_2 = visual.TextStim(win=win, name='ctext_2',
    text='C',
    font='Open Sans',
    pos=[0,0], height=0.05, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-14.0);

# --- Initialize components for Routine "end" ---
instr_image_6 = visual.ImageStim(
    win=win,
    name='instr_image_6', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(1.6, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.Clock()  # to track time remaining of each (possibly non-slip) routine 

# set up handler to look after randomisation of conditions etc
trialsdb = data.TrialHandler(nReps=0.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=[None],
    seed=None, name='trialsdb')
thisExp.addLoop(trialsdb)  # add the loop to the experiment
thisTrialsdb = trialsdb.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrialsdb.rgb)
if thisTrialsdb != None:
    for paramName in thisTrialsdb:
        exec('{} = thisTrialsdb[paramName]'.format(paramName))

for thisTrialsdb in trialsdb:
    currentLoop = trialsdb
    # abbreviate parameter names if possible (e.g. rgb = thisTrialsdb.rgb)
    if thisTrialsdb != None:
        for paramName in thisTrialsdb:
            exec('{} = thisTrialsdb[paramName]'.format(paramName))
    
    # set up handler to look after randomisation of conditions etc
    instr = data.TrialHandler(nReps=1.0, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('instructions.xlsx'),
        seed=None, name='instr')
    thisExp.addLoop(instr)  # add the loop to the experiment
    thisInstr = instr.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisInstr.rgb)
    if thisInstr != None:
        for paramName in thisInstr:
            exec('{} = thisInstr[paramName]'.format(paramName))
    
    for thisInstr in instr:
        currentLoop = instr
        # abbreviate parameter names if possible (e.g. rgb = thisInstr.rgb)
        if thisInstr != None:
            for paramName in thisInstr:
                exec('{} = thisInstr[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "instructions" ---
        continueRoutine = True
        # update component parameters for each repeat
        instr_image.setImage(thisSlide)
        # setup some python lists for storing info about the instrmouse
        instrmouse.x = []
        instrmouse.y = []
        instrmouse.leftButton = []
        instrmouse.midButton = []
        instrmouse.rightButton = []
        instrmouse.time = []
        gotValidClick = False  # until a click is received
        # keep track of which components have finished
        instructionsComponents = [instr_image, instrmouse]
        for thisComponent in instructionsComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "instructions" ---
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *instr_image* updates
            if instr_image.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                instr_image.frameNStart = frameN  # exact frame index
                instr_image.tStart = t  # local t and not account for scr refresh
                instr_image.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(instr_image, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'instr_image.started')
                instr_image.setAutoDraw(True)
            # *instrmouse* updates
            if instrmouse.status == NOT_STARTED and t >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                instrmouse.frameNStart = frameN  # exact frame index
                instrmouse.tStart = t  # local t and not account for scr refresh
                instrmouse.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(instrmouse, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.addData('instrmouse.started', t)
                instrmouse.status = STARTED
                instrmouse.mouseClock.reset()
                prevButtonState = instrmouse.getPressed()  # if button is down already this ISN'T a new click
            if instrmouse.status == STARTED:  # only update if started and not finished!
                buttons = instrmouse.getPressed()
                if buttons != prevButtonState:  # button state changed?
                    prevButtonState = buttons
                    if sum(buttons) > 0:  # state changed to a new click
                        x, y = instrmouse.getPos()
                        instrmouse.x.append(x)
                        instrmouse.y.append(y)
                        buttons = instrmouse.getPressed()
                        instrmouse.leftButton.append(buttons[0])
                        instrmouse.midButton.append(buttons[1])
                        instrmouse.rightButton.append(buttons[2])
                        instrmouse.time.append(instrmouse.mouseClock.getTime())
                        
                        continueRoutine = False  # abort routine on response
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in instructionsComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "instructions" ---
        for thisComponent in instructionsComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # store data for instr (TrialHandler)
        instr.addData('instrmouse.x', instrmouse.x)
        instr.addData('instrmouse.y', instrmouse.y)
        instr.addData('instrmouse.leftButton', instrmouse.leftButton)
        instr.addData('instrmouse.midButton', instrmouse.midButton)
        instr.addData('instrmouse.rightButton', instrmouse.rightButton)
        instr.addData('instrmouse.time', instrmouse.time)
        # the Routine "instructions" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
    # completed 1.0 repeats of 'instr'
    
    
    # set up handler to look after randomisation of conditions etc
    scan = data.TrialHandler(nReps=5.0, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions('scanning.xlsx'),
        seed=None, name='scan')
    thisExp.addLoop(scan)  # add the loop to the experiment
    thisScan = scan.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisScan.rgb)
    if thisScan != None:
        for paramName in thisScan:
            exec('{} = thisScan[paramName]'.format(paramName))
    
    for thisScan in scan:
        currentLoop = scan
        # abbreviate parameter names if possible (e.g. rgb = thisScan.rgb)
        if thisScan != None:
            for paramName in thisScan:
                exec('{} = thisScan[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "scan_for_players" ---
        continueRoutine = True
        # update component parameters for each repeat
        instr_image_2.setImage(thisSlide)
        # keep track of which components have finished
        scan_for_playersComponents = [instr_image_2]
        for thisComponent in scan_for_playersComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "scan_for_players" ---
        while continueRoutine and routineTimer.getTime() < 0.5:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *instr_image_2* updates
            if instr_image_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                instr_image_2.frameNStart = frameN  # exact frame index
                instr_image_2.tStart = t  # local t and not account for scr refresh
                instr_image_2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(instr_image_2, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'instr_image_2.started')
                instr_image_2.setAutoDraw(True)
            if instr_image_2.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > instr_image_2.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    instr_image_2.tStop = t  # not accounting for scr refresh
                    instr_image_2.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'instr_image_2.stopped')
                    instr_image_2.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in scan_for_playersComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "scan_for_players" ---
        for thisComponent in scan_for_playersComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # using non-slip timing so subtract the expected duration of this Routine
        routineTimer.addTime(-0.500000)
    # completed 5.0 repeats of 'scan'
    
    thisExp.nextEntry()
    
# completed 0.0 repeats of 'trialsdb'


# --- Prepare to start Routine "start" ---
continueRoutine = True
# update component parameters for each repeat
instr_image_3.setImage('stimuli/stim/Slide8.JPG')
# setup some python lists for storing info about the instrmouse_2
instrmouse_2.x = []
instrmouse_2.y = []
instrmouse_2.leftButton = []
instrmouse_2.midButton = []
instrmouse_2.rightButton = []
instrmouse_2.time = []
gotValidClick = False  # until a click is received
# keep track of which components have finished
startComponents = [instr_image_3, instrmouse_2]
for thisComponent in startComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "start" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instr_image_3* updates
    if instr_image_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instr_image_3.frameNStart = frameN  # exact frame index
        instr_image_3.tStart = t  # local t and not account for scr refresh
        instr_image_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instr_image_3, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'instr_image_3.started')
        instr_image_3.setAutoDraw(True)
    # *instrmouse_2* updates
    if instrmouse_2.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instrmouse_2.frameNStart = frameN  # exact frame index
        instrmouse_2.tStart = t  # local t and not account for scr refresh
        instrmouse_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instrmouse_2, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.addData('instrmouse_2.started', t)
        instrmouse_2.status = STARTED
        instrmouse_2.mouseClock.reset()
        prevButtonState = instrmouse_2.getPressed()  # if button is down already this ISN'T a new click
    if instrmouse_2.status == STARTED:  # only update if started and not finished!
        buttons = instrmouse_2.getPressed()
        if buttons != prevButtonState:  # button state changed?
            prevButtonState = buttons
            if sum(buttons) > 0:  # state changed to a new click
                x, y = instrmouse_2.getPos()
                instrmouse_2.x.append(x)
                instrmouse_2.y.append(y)
                buttons = instrmouse_2.getPressed()
                instrmouse_2.leftButton.append(buttons[0])
                instrmouse_2.midButton.append(buttons[1])
                instrmouse_2.rightButton.append(buttons[2])
                instrmouse_2.time.append(instrmouse_2.mouseClock.getTime())
                
                continueRoutine = False  # abort routine on response
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in startComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "start" ---
for thisComponent in startComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# store data for thisExp (ExperimentHandler)
thisExp.addData('instrmouse_2.x', instrmouse_2.x)
thisExp.addData('instrmouse_2.y', instrmouse_2.y)
thisExp.addData('instrmouse_2.leftButton', instrmouse_2.leftButton)
thisExp.addData('instrmouse_2.midButton', instrmouse_2.midButton)
thisExp.addData('instrmouse_2.rightButton', instrmouse_2.rightButton)
thisExp.addData('instrmouse_2.time', instrmouse_2.time)
thisExp.nextEntry()
# the Routine "start" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
trials = data.TrialHandler(nReps=1.0, method='random', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('trials.xlsx'),
    seed=None, name='trials')
thisExp.addLoop(trials)  # add the loop to the experiment
thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
if thisTrial != None:
    for paramName in thisTrial:
        exec('{} = thisTrial[paramName]'.format(paramName))

for thisTrial in trials:
    currentLoop = trials
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial:
            exec('{} = thisTrial[paramName]'.format(paramName))
    
    # set up handler to look after randomisation of conditions etc
    votes = data.TrialHandler(nReps=5.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='votes')
    thisExp.addLoop(votes)  # add the loop to the experiment
    thisVote = votes.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisVote.rgb)
    if thisVote != None:
        for paramName in thisVote:
            exec('{} = thisVote[paramName]'.format(paramName))
    
    for thisVote in votes:
        currentLoop = votes
        # abbreviate parameter names if possible (e.g. rgb = thisVote.rgb)
        if thisVote != None:
            for paramName in thisVote:
                exec('{} = thisVote[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "trial" ---
        continueRoutine = True
        # update component parameters for each repeat
        # Run 'Begin Routine' code from code
        n_a_votes = 0
        n_b_votes = 0
        n_c_votes = 0
        liney = -0.25
        
        if team_vote == 'A':
            n_a_votes = votes.thisN +1
            highlight_x = a_votes.pos[0]
            highlight_y = a_votes.pos[1]
        if team_vote == 'B':
            n_b_votes = votes.thisN+1
            highlight_x = b_votes.pos[0]
            highlight_y = b_votes.pos[1]
        if team_vote == 'C':
            n_c_votes = votes.thisN+1
            highlight_x = c_votes.pos[0]
            highlight_y = c_votes.pos[1]
        
        interval = random()+random()+random()
        instr_image_4.setImage('stimuli/stim/Slide9.JPG')
        a_votes.setText(n_a_votes)
        b_votes.setText(n_b_votes)
        c_votes.setText(n_c_votes)
        x_line.setPos((-0.03, liney+x_length/2))
        x_line.setSize((0.01, x_length))
        a_line.setPos((0.1, liney+a_length/2))
        a_line.setSize((0.01, a_length))
        b_line.setPos((0.2, liney+b_length/2))
        b_line.setSize((0.01, b_length))
        c_line.setPos((0.3, liney+c_length/2))
        c_line.setSize((0.01, c_length))
        highlight.setPos((highlight_x, highlight_y))
        sound_1.setSound('A', secs=0.1, hamming=True)
        sound_1.setVolume(1.0, log=False)
        xtext.setPos((x_line.pos[0], -0.3))
        atext.setPos((a_line.pos[0], -0.3))
        btext.setPos((b_line.pos[0], -0.3))
        ctext.setPos((c_line.pos[0], -0.3))
        # keep track of which components have finished
        trialComponents = [instr_image_4, a_votes, b_votes, c_votes, x_line, a_line, b_line, c_line, highlight, sound_1, xtext, atext, btext, ctext]
        for thisComponent in trialComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "trial" ---
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            # Run 'Each Frame' code from code
            if t > interval:
                continueRoutine = False
            
            # *instr_image_4* updates
            if instr_image_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                instr_image_4.frameNStart = frameN  # exact frame index
                instr_image_4.tStart = t  # local t and not account for scr refresh
                instr_image_4.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(instr_image_4, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'instr_image_4.started')
                instr_image_4.setAutoDraw(True)
            
            # *a_votes* updates
            if a_votes.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                a_votes.frameNStart = frameN  # exact frame index
                a_votes.tStart = t  # local t and not account for scr refresh
                a_votes.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(a_votes, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'a_votes.started')
                a_votes.setAutoDraw(True)
            
            # *b_votes* updates
            if b_votes.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                b_votes.frameNStart = frameN  # exact frame index
                b_votes.tStart = t  # local t and not account for scr refresh
                b_votes.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(b_votes, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'b_votes.started')
                b_votes.setAutoDraw(True)
            
            # *c_votes* updates
            if c_votes.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                c_votes.frameNStart = frameN  # exact frame index
                c_votes.tStart = t  # local t and not account for scr refresh
                c_votes.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(c_votes, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'c_votes.started')
                c_votes.setAutoDraw(True)
            
            # *x_line* updates
            if x_line.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                x_line.frameNStart = frameN  # exact frame index
                x_line.tStart = t  # local t and not account for scr refresh
                x_line.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(x_line, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'x_line.started')
                x_line.setAutoDraw(True)
            
            # *a_line* updates
            if a_line.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                a_line.frameNStart = frameN  # exact frame index
                a_line.tStart = t  # local t and not account for scr refresh
                a_line.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(a_line, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'a_line.started')
                a_line.setAutoDraw(True)
            
            # *b_line* updates
            if b_line.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                b_line.frameNStart = frameN  # exact frame index
                b_line.tStart = t  # local t and not account for scr refresh
                b_line.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(b_line, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'b_line.started')
                b_line.setAutoDraw(True)
            
            # *c_line* updates
            if c_line.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                c_line.frameNStart = frameN  # exact frame index
                c_line.tStart = t  # local t and not account for scr refresh
                c_line.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(c_line, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'c_line.started')
                c_line.setAutoDraw(True)
            
            # *highlight* updates
            if highlight.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                # keep track of start time/frame for later
                highlight.frameNStart = frameN  # exact frame index
                highlight.tStart = t  # local t and not account for scr refresh
                highlight.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(highlight, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'highlight.started')
                highlight.setAutoDraw(True)
            if highlight.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > highlight.tStartRefresh + 0.1-frameTolerance:
                    # keep track of stop time/frame for later
                    highlight.tStop = t  # not accounting for scr refresh
                    highlight.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'highlight.stopped')
                    highlight.setAutoDraw(False)
            # start/stop sound_1
            if sound_1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                sound_1.frameNStart = frameN  # exact frame index
                sound_1.tStart = t  # local t and not account for scr refresh
                sound_1.tStartRefresh = tThisFlipGlobal  # on global time
                # add timestamp to datafile
                thisExp.addData('sound_1.started', tThisFlipGlobal)
                sound_1.play(when=win)  # sync with win flip
            if sound_1.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > sound_1.tStartRefresh + 0.1-frameTolerance:
                    # keep track of stop time/frame for later
                    sound_1.tStop = t  # not accounting for scr refresh
                    sound_1.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'sound_1.stopped')
                    sound_1.stop()
            
            # *xtext* updates
            if xtext.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                xtext.frameNStart = frameN  # exact frame index
                xtext.tStart = t  # local t and not account for scr refresh
                xtext.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(xtext, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'xtext.started')
                xtext.setAutoDraw(True)
            
            # *atext* updates
            if atext.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                atext.frameNStart = frameN  # exact frame index
                atext.tStart = t  # local t and not account for scr refresh
                atext.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(atext, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'atext.started')
                atext.setAutoDraw(True)
            
            # *btext* updates
            if btext.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                btext.frameNStart = frameN  # exact frame index
                btext.tStart = t  # local t and not account for scr refresh
                btext.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(btext, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'btext.started')
                btext.setAutoDraw(True)
            
            # *ctext* updates
            if ctext.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                ctext.frameNStart = frameN  # exact frame index
                ctext.tStart = t  # local t and not account for scr refresh
                ctext.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(ctext, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'ctext.started')
                ctext.setAutoDraw(True)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in trialComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "trial" ---
        for thisComponent in trialComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        sound_1.stop()  # ensure sound has stopped at end of routine
        # the Routine "trial" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed 5.0 repeats of 'votes'
    
    
    # --- Prepare to start Routine "respond" ---
    continueRoutine = True
    # update component parameters for each repeat
    instr_image_5.setImage('stimuli/stim/Slide10.JPG')
    a_votes_2.setText(n_a_votes)
    b_votes_2.setText(n_b_votes)
    c_votes_2.setText(n_c_votes)
    x_line_2.setPos((-0.03, liney+x_length/2))
    x_line_2.setSize((0.01, x_length))
    a_line_2.setPos((0.1, liney+a_length/2))
    a_line_2.setSize((0.01, a_length))
    b_line_2.setPos((0.2, liney+b_length/2))
    b_line_2.setSize((0.01, b_length))
    c_line_2.setPos((0.3, liney+c_length/2))
    c_line_2.setSize((0.01, c_length))
    xtext_2.setPos((x_line.pos[0], -0.3))
    atext_2.setPos((a_line.pos[0], -0.3))
    btext_2.setPos((b_line.pos[0], -0.3))
    ctext_2.setPos((c_line.pos[0], -0.3))
    # keep track of which components have finished
    respondComponents = [instr_image_5, a_votes_2, b_votes_2, c_votes_2, x_line_2, a_line_2, b_line_2, c_line_2, Abutton, Bbutton, Cbutton, xtext_2, atext_2, btext_2, ctext_2]
    for thisComponent in respondComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "respond" ---
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *instr_image_5* updates
        if instr_image_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instr_image_5.frameNStart = frameN  # exact frame index
            instr_image_5.tStart = t  # local t and not account for scr refresh
            instr_image_5.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instr_image_5, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instr_image_5.started')
            instr_image_5.setAutoDraw(True)
        
        # *a_votes_2* updates
        if a_votes_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            a_votes_2.frameNStart = frameN  # exact frame index
            a_votes_2.tStart = t  # local t and not account for scr refresh
            a_votes_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(a_votes_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'a_votes_2.started')
            a_votes_2.setAutoDraw(True)
        
        # *b_votes_2* updates
        if b_votes_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            b_votes_2.frameNStart = frameN  # exact frame index
            b_votes_2.tStart = t  # local t and not account for scr refresh
            b_votes_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(b_votes_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'b_votes_2.started')
            b_votes_2.setAutoDraw(True)
        
        # *c_votes_2* updates
        if c_votes_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            c_votes_2.frameNStart = frameN  # exact frame index
            c_votes_2.tStart = t  # local t and not account for scr refresh
            c_votes_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(c_votes_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'c_votes_2.started')
            c_votes_2.setAutoDraw(True)
        
        # *x_line_2* updates
        if x_line_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            x_line_2.frameNStart = frameN  # exact frame index
            x_line_2.tStart = t  # local t and not account for scr refresh
            x_line_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(x_line_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'x_line_2.started')
            x_line_2.setAutoDraw(True)
        
        # *a_line_2* updates
        if a_line_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            a_line_2.frameNStart = frameN  # exact frame index
            a_line_2.tStart = t  # local t and not account for scr refresh
            a_line_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(a_line_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'a_line_2.started')
            a_line_2.setAutoDraw(True)
        
        # *b_line_2* updates
        if b_line_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            b_line_2.frameNStart = frameN  # exact frame index
            b_line_2.tStart = t  # local t and not account for scr refresh
            b_line_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(b_line_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'b_line_2.started')
            b_line_2.setAutoDraw(True)
        
        # *c_line_2* updates
        if c_line_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            c_line_2.frameNStart = frameN  # exact frame index
            c_line_2.tStart = t  # local t and not account for scr refresh
            c_line_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(c_line_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'c_line_2.started')
            c_line_2.setAutoDraw(True)
        
        # *Abutton* updates
        if Abutton.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Abutton.frameNStart = frameN  # exact frame index
            Abutton.tStart = t  # local t and not account for scr refresh
            Abutton.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Abutton, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Abutton.started')
            Abutton.setAutoDraw(True)
        if Abutton.status == STARTED:
            # check whether Abutton has been pressed
            if Abutton.isClicked:
                if not Abutton.wasClicked:
                    Abutton.timesOn.append(Abutton.buttonClock.getTime()) # store time of first click
                    Abutton.timesOff.append(Abutton.buttonClock.getTime()) # store time clicked until
                else:
                    Abutton.timesOff[-1] = Abutton.buttonClock.getTime() # update time clicked until
                if not Abutton.wasClicked:
                    continueRoutine = False  # end routine when Abutton is clicked
                    None
                Abutton.wasClicked = True  # if Abutton is still clicked next frame, it is not a new click
            else:
                Abutton.wasClicked = False  # if Abutton is clicked next frame, it is a new click
        else:
            Abutton.wasClicked = False  # if Abutton is clicked next frame, it is a new click
        
        # *Bbutton* updates
        if Bbutton.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Bbutton.frameNStart = frameN  # exact frame index
            Bbutton.tStart = t  # local t and not account for scr refresh
            Bbutton.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Bbutton, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Bbutton.started')
            Bbutton.setAutoDraw(True)
        if Bbutton.status == STARTED:
            # check whether Bbutton has been pressed
            if Bbutton.isClicked:
                if not Bbutton.wasClicked:
                    Bbutton.timesOn.append(Bbutton.buttonClock.getTime()) # store time of first click
                    Bbutton.timesOff.append(Bbutton.buttonClock.getTime()) # store time clicked until
                else:
                    Bbutton.timesOff[-1] = Bbutton.buttonClock.getTime() # update time clicked until
                if not Bbutton.wasClicked:
                    continueRoutine = False  # end routine when Bbutton is clicked
                    None
                Bbutton.wasClicked = True  # if Bbutton is still clicked next frame, it is not a new click
            else:
                Bbutton.wasClicked = False  # if Bbutton is clicked next frame, it is a new click
        else:
            Bbutton.wasClicked = False  # if Bbutton is clicked next frame, it is a new click
        
        # *Cbutton* updates
        if Cbutton.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            Cbutton.frameNStart = frameN  # exact frame index
            Cbutton.tStart = t  # local t and not account for scr refresh
            Cbutton.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(Cbutton, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'Cbutton.started')
            Cbutton.setAutoDraw(True)
        if Cbutton.status == STARTED:
            # check whether Cbutton has been pressed
            if Cbutton.isClicked:
                if not Cbutton.wasClicked:
                    Cbutton.timesOn.append(Cbutton.buttonClock.getTime()) # store time of first click
                    Cbutton.timesOff.append(Cbutton.buttonClock.getTime()) # store time clicked until
                else:
                    Cbutton.timesOff[-1] = Cbutton.buttonClock.getTime() # update time clicked until
                if not Cbutton.wasClicked:
                    continueRoutine = False  # end routine when Cbutton is clicked
                    None
                Cbutton.wasClicked = True  # if Cbutton is still clicked next frame, it is not a new click
            else:
                Cbutton.wasClicked = False  # if Cbutton is clicked next frame, it is a new click
        else:
            Cbutton.wasClicked = False  # if Cbutton is clicked next frame, it is a new click
        
        # *xtext_2* updates
        if xtext_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            xtext_2.frameNStart = frameN  # exact frame index
            xtext_2.tStart = t  # local t and not account for scr refresh
            xtext_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(xtext_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'xtext_2.started')
            xtext_2.setAutoDraw(True)
        
        # *atext_2* updates
        if atext_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            atext_2.frameNStart = frameN  # exact frame index
            atext_2.tStart = t  # local t and not account for scr refresh
            atext_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(atext_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'atext_2.started')
            atext_2.setAutoDraw(True)
        
        # *btext_2* updates
        if btext_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            btext_2.frameNStart = frameN  # exact frame index
            btext_2.tStart = t  # local t and not account for scr refresh
            btext_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(btext_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'btext_2.started')
            btext_2.setAutoDraw(True)
        
        # *ctext_2* updates
        if ctext_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ctext_2.frameNStart = frameN  # exact frame index
            ctext_2.tStart = t  # local t and not account for scr refresh
            ctext_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ctext_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'ctext_2.started')
            ctext_2.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in respondComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "respond" ---
    for thisComponent in respondComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials.addData('Abutton.numClicks', Abutton.numClicks)
    if Abutton.numClicks:
       trials.addData('Abutton.timesOn', Abutton.timesOn)
       trials.addData('Abutton.timesOff', Abutton.timesOff)
    else:
       trials.addData('Abutton.timesOn', "")
       trials.addData('Abutton.timesOff', "")
    trials.addData('Bbutton.numClicks', Bbutton.numClicks)
    if Bbutton.numClicks:
       trials.addData('Bbutton.timesOn', Bbutton.timesOn)
       trials.addData('Bbutton.timesOff', Bbutton.timesOff)
    else:
       trials.addData('Bbutton.timesOn', "")
       trials.addData('Bbutton.timesOff', "")
    trials.addData('Cbutton.numClicks', Cbutton.numClicks)
    if Cbutton.numClicks:
       trials.addData('Cbutton.timesOn', Cbutton.timesOn)
       trials.addData('Cbutton.timesOff', Cbutton.timesOff)
    else:
       trials.addData('Cbutton.timesOn', "")
       trials.addData('Cbutton.timesOff', "")
    # the Routine "respond" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1.0 repeats of 'trials'


# --- Prepare to start Routine "end" ---
continueRoutine = True
# update component parameters for each repeat
instr_image_6.setImage('stimuli/stim/Slide11.JPG')
# keep track of which components have finished
endComponents = [instr_image_6]
for thisComponent in endComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "end" ---
while continueRoutine and routineTimer.getTime() < 2.0:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *instr_image_6* updates
    if instr_image_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        instr_image_6.frameNStart = frameN  # exact frame index
        instr_image_6.tStart = t  # local t and not account for scr refresh
        instr_image_6.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(instr_image_6, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'instr_image_6.started')
        instr_image_6.setAutoDraw(True)
    if instr_image_6.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > instr_image_6.tStartRefresh + 2-frameTolerance:
            # keep track of stop time/frame for later
            instr_image_6.tStop = t  # not accounting for scr refresh
            instr_image_6.frameNStop = frameN  # exact frame index
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instr_image_6.stopped')
            instr_image_6.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in endComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "end" ---
for thisComponent in endComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# using non-slip timing so subtract the expected duration of this Routine
routineTimer.addTime(-2.000000)

# --- End experiment ---
# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
if eyetracker:
    eyetracker.setConnectionState(False)
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()

The images used in this task was downloaded from freepik.com. Below are the attributions associated with this task:

<a href="https://www.freepik.com/vectors/futuristic-background">Futuristic background vector created by coolvector - Error! Hyperlink reference not valid.>

<a href='https://www.freepik.com/vectors/jazz-logo'>Jazz logo vector created by freepik - www.freepik.com</a>	
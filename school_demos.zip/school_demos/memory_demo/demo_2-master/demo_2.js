﻿/*************** 
 * Demo_2 Test *
 ***************/

import { core, data, sound, util, visual, hardware } from './lib/psychojs-2022.2.0.js';
const { PsychoJS } = core;
const { TrialHandler, MultiStairHandler } = data;
const { Scheduler } = util;
//some handy aliases as in the psychopy scripts;
const { abs, sin, cos, PI: pi, sqrt } = Math;
const { round } = util;


// store info about the experiment session:
let expName = 'demo_2';  // from the Builder filename that created this script
let expInfo = {
    'participant': '',
    'session': '001',
};

// Start code blocks for 'Before Experiment'
// init psychoJS:
const psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: true,
  color: new util.Color('black'),
  units: 'height',
  waitBlanking: true
});
// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
const instructLoopLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(instructLoopLoopBegin(instructLoopLoopScheduler));
flowScheduler.add(instructLoopLoopScheduler);
flowScheduler.add(instructLoopLoopEnd);
const trialsLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trialsLoopBegin(trialsLoopScheduler));
flowScheduler.add(trialsLoopScheduler);
flowScheduler.add(trialsLoopEnd);
flowScheduler.add(recall_instructRoutineBegin());
flowScheduler.add(recall_instructRoutineEachFrame());
flowScheduler.add(recall_instructRoutineEnd());
flowScheduler.add(round1RoutineBegin());
flowScheduler.add(round1RoutineEachFrame());
flowScheduler.add(round1RoutineEnd());
const trials_3LoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trials_3LoopBegin(trials_3LoopScheduler));
flowScheduler.add(trials_3LoopScheduler);
flowScheduler.add(trials_3LoopEnd);
flowScheduler.add(round2RoutineBegin());
flowScheduler.add(round2RoutineEachFrame());
flowScheduler.add(round2RoutineEnd());
const trials_4LoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trials_4LoopBegin(trials_4LoopScheduler));
flowScheduler.add(trials_4LoopScheduler);
flowScheduler.add(trials_4LoopEnd);
flowScheduler.add(endRoutineBegin());
flowScheduler.add(endRoutineEachFrame());
flowScheduler.add(endRoutineEnd());
flowScheduler.add(quitPsychoJS, '', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, '', false);

psychoJS.start({
  expName: expName,
  expInfo: expInfo,
  resources: [
    {'name': 'stim/audio_stim/Baby.wav', 'path': 'stim/audio_stim/Baby.wav'},
    {'name': 'stim/instructs/ins3.png', 'path': 'stim/instructs/ins3.png'},
    {'name': 'stim/audio_stim/Flag.wav', 'path': 'stim/audio_stim/Flag.wav'},
    {'name': 'stim/audio_stim/King.wav', 'path': 'stim/audio_stim/King.wav'},
    {'name': 'stim/recall_2/hotel.png', 'path': 'stim/recall_2/hotel.png'},
    {'name': 'stim/recall_1/table.png', 'path': 'stim/recall_1/table.png'},
    {'name': 'stim/audio_stim/Gold.wav', 'path': 'stim/audio_stim/Gold.wav'},
    {'name': 'stim/headphone.png', 'path': 'stim/headphone.png'},
    {'name': 'stim/recall_1/child.png', 'path': 'stim/recall_1/child.png'},
    {'name': 'stim/audio_stim/Skin.wav', 'path': 'stim/audio_stim/Skin.wav'},
    {'name': 'stim/instructs/ins1.png', 'path': 'stim/instructs/ins1.png'},
    {'name': 'stim/audio_stim/Book.wav', 'path': 'stim/audio_stim/Book.wav'},
    {'name': 'stim/recall_2/earth.png', 'path': 'stim/recall_2/earth.png'},
    {'name': 'stim/recall_2/tree.png', 'path': 'stim/recall_2/tree.png'},
    {'name': 'stim/recall_2/sky.png', 'path': 'stim/recall_2/sky.png'},
    {'name': 'word_list.xlsx', 'path': 'word_list.xlsx'},
    {'name': 'stim/recall_1/sea.png', 'path': 'stim/recall_1/sea.png'},
    {'name': 'stim/recall_1/baby.png', 'path': 'stim/recall_1/baby.png'},
    {'name': 'stim/recall_2/ball.png', 'path': 'stim/recall_2/ball.png'},
    {'name': 'stim/recall_1/flag.png', 'path': 'stim/recall_1/flag.png'},
    {'name': 'stim/instructs/recall_ins.png', 'path': 'stim/instructs/recall_ins.png'},
    {'name': 'stim/recall_1/metal.png', 'path': 'stim/recall_1/metal.png'},
    {'name': 'stim/recall_2/blood.png', 'path': 'stim/recall_2/blood.png'},
    {'name': 'stim/recall_1/fire.png', 'path': 'stim/recall_1/fire.png'},
    {'name': 'stim/instructs/round1.png', 'path': 'stim/instructs/round1.png'},
    {'name': 'stim/instructs/ins2.png', 'path': 'stim/instructs/ins2.png'},
    {'name': 'stim/recall_2/home.png', 'path': 'stim/recall_2/home.png'},
    {'name': 'stim/recall_2/gold.png', 'path': 'stim/recall_2/gold.png'},
    {'name': 'stim/audio_stim/Sky.wav', 'path': 'stim/audio_stim/Sky.wav'},
    {'name': 'stim/audio_stim/Girl.wav', 'path': 'stim/audio_stim/Girl.wav'},
    {'name': 'instruct_block.xlsx', 'path': 'instruct_block.xlsx'},
    {'name': 'recall2_correctAnswer.xlsx', 'path': 'recall2_correctAnswer.xlsx'},
    {'name': 'stim/recall_2/rock.png', 'path': 'stim/recall_2/rock.png'},
    {'name': 'stim/recall_1/book.png', 'path': 'stim/recall_1/book.png'},
    {'name': 'stim/recall_1/water.png', 'path': 'stim/recall_1/water.png'},
    {'name': 'stim/audio_stim/Wife.wav', 'path': 'stim/audio_stim/Wife.wav'},
    {'name': 'stim/recall_2/house.png', 'path': 'stim/recall_2/house.png'},
    {'name': 'stim/audio_stim/Home.wav', 'path': 'stim/audio_stim/Home.wav'},
    {'name': 'stim/audio_stim/Sea.wav', 'path': 'stim/audio_stim/Sea.wav'},
    {'name': 'stim/instructs/round2.png', 'path': 'stim/instructs/round2.png'},
    {'name': 'stim/next.png', 'path': 'stim/next.png'},
    {'name': 'recall1_correctAnswer.xlsx', 'path': 'recall1_correctAnswer.xlsx'},
    {'name': 'stim/audio_stim/Rock.wav', 'path': 'stim/audio_stim/Rock.wav'},
    {'name': 'stim/bg.png', 'path': 'stim/bg.png'},
    {'name': 'stim/recall_1/shoes.png', 'path': 'stim/recall_1/shoes.png'},
    {'name': 'stim/audio_stim/Fire.wav', 'path': 'stim/audio_stim/Fire.wav'},
    {'name': 'stim/branding.png', 'path': 'stim/branding.png'},
    {'name': 'stim/audio_stim/Tree.wav', 'path': 'stim/audio_stim/Tree.wav'}
  ]
});

psychoJS.experimentLogger.setLevel(core.Logger.ServerLevel.EXP);


var currentLoop;
var frameDur;
async function updateInfo() {
  currentLoop = psychoJS.experiment;  // right now there are no loops
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '2022.2.0';
  expInfo['OS'] = window.navigator.platform;

  psychoJS.experiment.dataFileName = (("." + "/") + `data/${expInfo["participant"]}_${expName}_${expInfo["date"]}`);

  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0 / Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0 / 60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  
  return Scheduler.Event.NEXT;
}


var instructionsClock;
var image_bg_inst;
var image_ins;
var image_next;
var mouse_inst;
var trialClock;
var image_bg_trial;
var image_hp;
var audioStim;
var recall_instructClock;
var image_bg_trial_3;
var image_recall_ins;
var image_next_9;
var mouse_recall_ins;
var round1Clock;
var image_bg_trial_4;
var image_round1;
var recall1Clock;
var image_bg_words_2;
var baby;
var flag;
var water;
var book;
var fire;
var sea;
var metal;
var child;
var table;
var shoes;
var image_next_6;
var mouse_recall1;
var resultsClock;
var image_bg_TR_2;
var text;
var image_next_4;
var mouse_2;
var round2Clock;
var image_bg_trial_5;
var image_round2;
var recall2Clock;
var image_bg_words_3;
var earth;
var blood;
var house;
var hotel;
var ball;
var sky;
var rock;
var gold;
var tree;
var home;
var image_next_7;
var mouse_recall2;
var results_2Clock;
var image_bg_TR_3;
var text_3;
var image_next_8;
var mouse_3;
var endClock;
var image_bg_trial_6;
var image_branding;
var globalClock;
var routineTimer;
async function experimentInit() {
  // Initialize components for Routine "instructions"
  instructionsClock = new util.Clock();
  image_bg_inst = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_bg_inst', units : undefined, 
    image : 'stim/bg.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [1.8, 1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  image_ins = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_ins', units : undefined, 
    image : undefined, mask : undefined,
    ori : 0.0, pos : [0, 0], size : 1.0,
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  image_next = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_next', units : undefined, 
    image : 'stim/next.png', mask : undefined,
    ori : 0.0, pos : [0.375, (- 0.35)], size : [0.2, 0.15],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -2.0 
  });
  mouse_inst = new core.Mouse({
    win: psychoJS.window,
  });
  mouse_inst.mouseClock = new util.Clock();
  // Initialize components for Routine "trial"
  trialClock = new util.Clock();
  image_bg_trial = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_bg_trial', units : undefined, 
    image : 'stim/bg.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [1.8, 1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  image_hp = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_hp', units : undefined, 
    image : 'stim/headphone.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [0.5, 0.5],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  audioStim = new sound.Sound({
    win: psychoJS.window,
    value: 'A',
    secs: (- 1),
    });
  audioStim.setVolume(1.0);
  // Initialize components for Routine "recall_instruct"
  recall_instructClock = new util.Clock();
  image_bg_trial_3 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_bg_trial_3', units : undefined, 
    image : 'stim/bg.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [1.8, 1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  image_recall_ins = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_recall_ins', units : undefined, 
    image : 'stim/instructs/recall_ins.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [(2.651 * 0.45), 0.45],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  image_next_9 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_next_9', units : undefined, 
    image : 'stim/next.png', mask : undefined,
    ori : 0.0, pos : [0.375, (- 0.35)], size : [0.2, 0.15],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -2.0 
  });
  mouse_recall_ins = new core.Mouse({
    win: psychoJS.window,
  });
  mouse_recall_ins.mouseClock = new util.Clock();
  // Initialize components for Routine "round1"
  round1Clock = new util.Clock();
  image_bg_trial_4 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_bg_trial_4', units : undefined, 
    image : 'stim/bg.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [1.8, 1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  image_round1 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_round1', units : undefined, 
    image : 'stim/instructs/round1.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [(2.615 * 0.4), 0.4],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  // Initialize components for Routine "recall1"
  recall1Clock = new util.Clock();
  image_bg_words_2 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_bg_words_2', units : undefined, 
    image : 'stim/bg.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [1.8, 1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  baby = new visual.ImageStim({
    win : psychoJS.window,
    name : 'baby', units : undefined, 
    image : 'stim/recall_1/baby.png', mask : undefined,
    ori : 0.0, pos : [(- 0.6), 0.175], size : [(1.915 * 0.1), 0.1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -2.0 
  });
  flag = new visual.ImageStim({
    win : psychoJS.window,
    name : 'flag', units : undefined, 
    image : 'stim/recall_1/flag.png', mask : undefined,
    ori : 0.0, pos : [(- 0.2), 0.175], size : [(1.915 * 0.1), 0.1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -3.0 
  });
  water = new visual.ImageStim({
    win : psychoJS.window,
    name : 'water', units : undefined, 
    image : 'stim/recall_1/water.png', mask : undefined,
    ori : 0.0, pos : [0.2, 0.175], size : [(1.915 * 0.1), 0.1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -4.0 
  });
  book = new visual.ImageStim({
    win : psychoJS.window,
    name : 'book', units : undefined, 
    image : 'stim/recall_1/book.png', mask : undefined,
    ori : 0.0, pos : [(- 0.6), (- 0.175)], size : [(1.915 * 0.1), 0.1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -5.0 
  });
  fire = new visual.ImageStim({
    win : psychoJS.window,
    name : 'fire', units : undefined, 
    image : 'stim/recall_1/fire.png', mask : undefined,
    ori : 0.0, pos : [(- 0.6), 0], size : [(1.915 * 0.1), 0.1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -6.0 
  });
  sea = new visual.ImageStim({
    win : psychoJS.window,
    name : 'sea', units : undefined, 
    image : 'stim/recall_1/sea.png', mask : undefined,
    ori : 0.0, pos : [(- 0.2), 0], size : [(1.915 * 0.1), 0.1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -7.0 
  });
  metal = new visual.ImageStim({
    win : psychoJS.window,
    name : 'metal', units : undefined, 
    image : 'stim/recall_1/metal.png', mask : undefined,
    ori : 0.0, pos : [0.2, 0], size : [(1.915 * 0.1), 0.1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -8.0 
  });
  child = new visual.ImageStim({
    win : psychoJS.window,
    name : 'child', units : undefined, 
    image : 'stim/recall_1/child.png', mask : undefined,
    ori : 0.0, pos : [0.6, 0], size : [(1.915 * 0.1), 0.1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -9.0 
  });
  table = new visual.ImageStim({
    win : psychoJS.window,
    name : 'table', units : undefined, 
    image : 'stim/recall_1/table.png', mask : undefined,
    ori : 0.0, pos : [(- 0.2), (- 0.175)], size : [(1.915 * 0.1), 0.1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -10.0 
  });
  shoes = new visual.ImageStim({
    win : psychoJS.window,
    name : 'shoes', units : undefined, 
    image : 'stim/recall_1/shoes.png', mask : undefined,
    ori : 0.0, pos : [0.2, (- 0.175)], size : [(1.915 * 0.1), 0.1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -11.0 
  });
  image_next_6 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_next_6', units : undefined, 
    image : 'stim/next.png', mask : undefined,
    ori : 0.0, pos : [0.375, (- 0.35)], size : [0.2, 0.15],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -12.0 
  });
  mouse_recall1 = new core.Mouse({
    win: psychoJS.window,
  });
  mouse_recall1.mouseClock = new util.Clock();
  // Initialize components for Routine "results"
  resultsClock = new util.Clock();
  image_bg_TR_2 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_bg_TR_2', units : undefined, 
    image : 'stim/bg.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [1.8, 1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  text = new visual.TextStim({
    win: psychoJS.window,
    name: 'text',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.08,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: -1.0 
  });
  
  image_next_4 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_next_4', units : undefined, 
    image : 'stim/next.png', mask : undefined,
    ori : 0.0, pos : [0.375, (- 0.35)], size : [0.2, 0.15],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -2.0 
  });
  mouse_2 = new core.Mouse({
    win: psychoJS.window,
  });
  mouse_2.mouseClock = new util.Clock();
  // Initialize components for Routine "round2"
  round2Clock = new util.Clock();
  image_bg_trial_5 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_bg_trial_5', units : undefined, 
    image : 'stim/bg.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [1.8, 1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  image_round2 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_round2', units : undefined, 
    image : 'stim/instructs/round2.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [(2.615 * 0.4), 0.4],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  // Initialize components for Routine "recall2"
  recall2Clock = new util.Clock();
  image_bg_words_3 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_bg_words_3', units : undefined, 
    image : 'stim/bg.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [1.8, 1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  earth = new visual.ImageStim({
    win : psychoJS.window,
    name : 'earth', units : undefined, 
    image : 'stim/recall_2/earth.png', mask : undefined,
    ori : 0.0, pos : [(- 0.6), 0.175], size : [(1.915 * 0.1), 0.1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -2.0 
  });
  blood = new visual.ImageStim({
    win : psychoJS.window,
    name : 'blood', units : undefined, 
    image : 'stim/recall_2/blood.png', mask : undefined,
    ori : 0.0, pos : [(- 0.2), 0.175], size : [(1.915 * 0.1), 0.1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -3.0 
  });
  house = new visual.ImageStim({
    win : psychoJS.window,
    name : 'house', units : undefined, 
    image : 'stim/recall_2/house.png', mask : undefined,
    ori : 0.0, pos : [0.2, 0.175], size : [(1.915 * 0.1), 0.1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -4.0 
  });
  hotel = new visual.ImageStim({
    win : psychoJS.window,
    name : 'hotel', units : undefined, 
    image : 'stim/recall_2/hotel.png', mask : undefined,
    ori : 0.0, pos : [(- 0.6), (- 0.175)], size : [(1.915 * 0.1), 0.1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -5.0 
  });
  ball = new visual.ImageStim({
    win : psychoJS.window,
    name : 'ball', units : undefined, 
    image : 'stim/recall_2/ball.png', mask : undefined,
    ori : 0.0, pos : [(- 0.6), 0], size : [(1.915 * 0.1), 0.1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -6.0 
  });
  sky = new visual.ImageStim({
    win : psychoJS.window,
    name : 'sky', units : undefined, 
    image : 'stim/recall_2/sky.png', mask : undefined,
    ori : 0.0, pos : [(- 0.2), 0], size : [(1.915 * 0.1), 0.1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -7.0 
  });
  rock = new visual.ImageStim({
    win : psychoJS.window,
    name : 'rock', units : undefined, 
    image : 'stim/recall_2/rock.png', mask : undefined,
    ori : 0.0, pos : [0.2, 0], size : [(1.915 * 0.1), 0.1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -8.0 
  });
  gold = new visual.ImageStim({
    win : psychoJS.window,
    name : 'gold', units : undefined, 
    image : 'stim/recall_2/gold.png', mask : undefined,
    ori : 0.0, pos : [0.6, 0], size : [(1.915 * 0.1), 0.1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -9.0 
  });
  tree = new visual.ImageStim({
    win : psychoJS.window,
    name : 'tree', units : undefined, 
    image : 'stim/recall_2/tree.png', mask : undefined,
    ori : 0.0, pos : [(- 0.2), (- 0.175)], size : [(1.915 * 0.1), 0.1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -10.0 
  });
  home = new visual.ImageStim({
    win : psychoJS.window,
    name : 'home', units : undefined, 
    image : 'stim/recall_2/home.png', mask : undefined,
    ori : 0.0, pos : [0.2, (- 0.175)], size : [(1.915 * 0.1), 0.1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -11.0 
  });
  image_next_7 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_next_7', units : undefined, 
    image : 'stim/next.png', mask : undefined,
    ori : 0.0, pos : [0.375, (- 0.35)], size : [0.2, 0.15],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -12.0 
  });
  mouse_recall2 = new core.Mouse({
    win: psychoJS.window,
  });
  mouse_recall2.mouseClock = new util.Clock();
  // Initialize components for Routine "results_2"
  results_2Clock = new util.Clock();
  image_bg_TR_3 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_bg_TR_3', units : undefined, 
    image : 'stim/bg.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [1.8, 1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  text_3 = new visual.TextStim({
    win: psychoJS.window,
    name: 'text_3',
    text: '',
    font: 'Arial',
    units: undefined, 
    pos: [0, 0], height: 0.08,  wrapWidth: undefined, ori: 0.0,
    languageStyle: 'LTR',
    color: new util.Color('white'),  opacity: undefined,
    depth: -1.0 
  });
  
  image_next_8 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_next_8', units : undefined, 
    image : 'stim/next.png', mask : undefined,
    ori : 0.0, pos : [0.375, (- 0.35)], size : [0.2, 0.15],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -2.0 
  });
  mouse_3 = new core.Mouse({
    win: psychoJS.window,
  });
  mouse_3.mouseClock = new util.Clock();
  // Initialize components for Routine "end"
  endClock = new util.Clock();
  image_bg_trial_6 = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_bg_trial_6', units : undefined, 
    image : 'stim/bg.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [1.8, 1],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : 0.0 
  });
  image_branding = new visual.ImageStim({
    win : psychoJS.window,
    name : 'image_branding', units : undefined, 
    image : 'stim/branding.png', mask : undefined,
    ori : 0.0, pos : [0, 0], size : [(2.526 * 0.45), 0.45],
    color : new util.Color([1,1,1]), opacity : undefined,
    flipHoriz : false, flipVert : false,
    texRes : 128.0, interpolate : true, depth : -1.0 
  });
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}


var instructLoop;
function instructLoopLoopBegin(instructLoopLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    instructLoop = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'instruct_block.xlsx',
      seed: undefined, name: 'instructLoop'
    });
    psychoJS.experiment.addLoop(instructLoop); // add the loop to the experiment
    currentLoop = instructLoop;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisInstructLoop of instructLoop) {
      snapshot = instructLoop.getSnapshot();
      instructLoopLoopScheduler.add(importConditions(snapshot));
      instructLoopLoopScheduler.add(instructionsRoutineBegin(snapshot));
      instructLoopLoopScheduler.add(instructionsRoutineEachFrame());
      instructLoopLoopScheduler.add(instructionsRoutineEnd(snapshot));
      instructLoopLoopScheduler.add(instructLoopLoopEndIteration(instructLoopLoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function instructLoopLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(instructLoop);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function instructLoopLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials;
function trialsLoopBegin(trialsLoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'word_list.xlsx',
      seed: undefined, name: 'trials'
    });
    psychoJS.experiment.addLoop(trials); // add the loop to the experiment
    currentLoop = trials;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisTrial of trials) {
      snapshot = trials.getSnapshot();
      trialsLoopScheduler.add(importConditions(snapshot));
      trialsLoopScheduler.add(trialRoutineBegin(snapshot));
      trialsLoopScheduler.add(trialRoutineEachFrame());
      trialsLoopScheduler.add(trialRoutineEnd(snapshot));
      trialsLoopScheduler.add(trialsLoopEndIteration(trialsLoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function trialsLoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trialsLoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials_3;
function trials_3LoopBegin(trials_3LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials_3 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'recall1_correctAnswer.xlsx',
      seed: undefined, name: 'trials_3'
    });
    psychoJS.experiment.addLoop(trials_3); // add the loop to the experiment
    currentLoop = trials_3;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisTrial_3 of trials_3) {
      snapshot = trials_3.getSnapshot();
      trials_3LoopScheduler.add(importConditions(snapshot));
      trials_3LoopScheduler.add(recall1RoutineBegin(snapshot));
      trials_3LoopScheduler.add(recall1RoutineEachFrame());
      trials_3LoopScheduler.add(recall1RoutineEnd(snapshot));
      trials_3LoopScheduler.add(resultsRoutineBegin(snapshot));
      trials_3LoopScheduler.add(resultsRoutineEachFrame());
      trials_3LoopScheduler.add(resultsRoutineEnd(snapshot));
      trials_3LoopScheduler.add(trials_3LoopEndIteration(trials_3LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function trials_3LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials_3);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trials_3LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var trials_4;
function trials_4LoopBegin(trials_4LoopScheduler, snapshot) {
  return async function() {
    TrialHandler.fromSnapshot(snapshot); // update internal variables (.thisN etc) of the loop
    
    // set up handler to look after randomisation of conditions etc
    trials_4 = new TrialHandler({
      psychoJS: psychoJS,
      nReps: 1, method: TrialHandler.Method.SEQUENTIAL,
      extraInfo: expInfo, originPath: undefined,
      trialList: 'recall2_correctAnswer.xlsx',
      seed: undefined, name: 'trials_4'
    });
    psychoJS.experiment.addLoop(trials_4); // add the loop to the experiment
    currentLoop = trials_4;  // we're now the current loop
    
    // Schedule all the trials in the trialList:
    for (const thisTrial_4 of trials_4) {
      snapshot = trials_4.getSnapshot();
      trials_4LoopScheduler.add(importConditions(snapshot));
      trials_4LoopScheduler.add(recall2RoutineBegin(snapshot));
      trials_4LoopScheduler.add(recall2RoutineEachFrame());
      trials_4LoopScheduler.add(recall2RoutineEnd(snapshot));
      trials_4LoopScheduler.add(results_2RoutineBegin(snapshot));
      trials_4LoopScheduler.add(results_2RoutineEachFrame());
      trials_4LoopScheduler.add(results_2RoutineEnd(snapshot));
      trials_4LoopScheduler.add(trials_4LoopEndIteration(trials_4LoopScheduler, snapshot));
    }
    
    return Scheduler.Event.NEXT;
  }
}


async function trials_4LoopEnd() {
  // terminate loop
  psychoJS.experiment.removeLoop(trials_4);
  // update the current loop from the ExperimentHandler
  if (psychoJS.experiment._unfinishedLoops.length>0)
    currentLoop = psychoJS.experiment._unfinishedLoops.at(-1);
  else
    currentLoop = psychoJS.experiment;  // so we use addData from the experiment
  return Scheduler.Event.NEXT;
}


function trials_4LoopEndIteration(scheduler, snapshot) {
  // ------Prepare for next entry------
  return async function () {
    if (typeof snapshot !== 'undefined') {
      // ------Check if user ended loop early------
      if (snapshot.finished) {
        // Check for and save orphaned data
        if (psychoJS.experiment.isEntryEmpty()) {
          psychoJS.experiment.nextEntry(snapshot);
        }
        scheduler.stop();
      } else {
        psychoJS.experiment.nextEntry(snapshot);
      }
    return Scheduler.Event.NEXT;
    }
  };
}


var t;
var frameN;
var continueRoutine;
var gotValidClick;
var instructionsComponents;
function instructionsRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'instructions' ---
    t = 0;
    instructionsClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    image_ins.setSize([(img_size * 0.5), 0.5]);
    image_ins.setImage(ins_img);
    // setup some python lists for storing info about the mouse_inst
    mouse_inst.clicked_name = [];
    gotValidClick = false; // until a click is received
    // keep track of which components have finished
    instructionsComponents = [];
    instructionsComponents.push(image_bg_inst);
    instructionsComponents.push(image_ins);
    instructionsComponents.push(image_next);
    instructionsComponents.push(mouse_inst);
    
    for (const thisComponent of instructionsComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


var prevButtonState;
var _mouseButtons;
function instructionsRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'instructions' ---
    // get current time
    t = instructionsClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *image_bg_inst* updates
    if (t >= 0.0 && image_bg_inst.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_bg_inst.tStart = t;  // (not accounting for frame time here)
      image_bg_inst.frameNStart = frameN;  // exact frame index
      
      image_bg_inst.setAutoDraw(true);
    }

    
    // *image_ins* updates
    if (t >= 0.0 && image_ins.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_ins.tStart = t;  // (not accounting for frame time here)
      image_ins.frameNStart = frameN;  // exact frame index
      
      image_ins.setAutoDraw(true);
    }

    
    // *image_next* updates
    if (t >= 0.0 && image_next.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_next.tStart = t;  // (not accounting for frame time here)
      image_next.frameNStart = frameN;  // exact frame index
      
      image_next.setAutoDraw(true);
    }

    // *mouse_inst* updates
    if (t >= 0.0 && mouse_inst.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      mouse_inst.tStart = t;  // (not accounting for frame time here)
      mouse_inst.frameNStart = frameN;  // exact frame index
      
      mouse_inst.status = PsychoJS.Status.STARTED;
      mouse_inst.mouseClock.reset();
      prevButtonState = mouse_inst.getPressed();  // if button is down already this ISN'T a new click
      }
    if (mouse_inst.status === PsychoJS.Status.STARTED) {  // only update if started and not finished!
      _mouseButtons = mouse_inst.getPressed();
      if (!_mouseButtons.every( (e,i,) => (e == prevButtonState[i]) )) { // button state changed?
        prevButtonState = _mouseButtons;
        if (_mouseButtons.reduce( (e, acc) => (e+acc) ) > 0) { // state changed to a new click
          // check if the mouse was inside our 'clickable' objects
          gotValidClick = false;
          for (const obj of [image_next]) {
            if (obj.contains(mouse_inst)) {
              gotValidClick = true;
              mouse_inst.clicked_name.push(obj.name)
            }
          }
          if (gotValidClick === true) { // abort routine on response
            continueRoutine = false;
          }
        }
      }
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of instructionsComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


var _mouseXYs;
function instructionsRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'instructions' ---
    for (const thisComponent of instructionsComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // store data for psychoJS.experiment (ExperimentHandler)
    _mouseXYs = mouse_inst.getPos();
    _mouseButtons = mouse_inst.getPressed();
    psychoJS.experiment.addData('mouse_inst.x', _mouseXYs[0]);
    psychoJS.experiment.addData('mouse_inst.y', _mouseXYs[1]);
    psychoJS.experiment.addData('mouse_inst.leftButton', _mouseButtons[0]);
    psychoJS.experiment.addData('mouse_inst.midButton', _mouseButtons[1]);
    psychoJS.experiment.addData('mouse_inst.rightButton', _mouseButtons[2]);
    if (mouse_inst.clicked_name.length > 0) {
      psychoJS.experiment.addData('mouse_inst.clicked_name', mouse_inst.clicked_name[0]);}
    // the Routine "instructions" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var trialComponents;
function trialRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'trial' ---
    t = 0;
    trialClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    audioStim = new sound.Sound({
    win: psychoJS.window,
    value: list_of_words,
    secs: -1,
    });
    audioStim.setVolume(1.0);
    // keep track of which components have finished
    trialComponents = [];
    trialComponents.push(image_bg_trial);
    trialComponents.push(image_hp);
    trialComponents.push(audioStim);
    
    for (const thisComponent of trialComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function trialRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'trial' ---
    // get current time
    t = trialClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *image_bg_trial* updates
    if (t >= 0.0 && image_bg_trial.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_bg_trial.tStart = t;  // (not accounting for frame time here)
      image_bg_trial.frameNStart = frameN;  // exact frame index
      
      image_bg_trial.setAutoDraw(true);
    }

    
    // *image_hp* updates
    if (t >= 0.0 && image_hp.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_hp.tStart = t;  // (not accounting for frame time here)
      image_hp.frameNStart = frameN;  // exact frame index
      
      image_hp.setAutoDraw(true);
    }

    // start/stop audioStim
    if (t >= 0.5 && audioStim.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      audioStim.tStart = t;  // (not accounting for frame time here)
      audioStim.frameNStart = frameN;  // exact frame index
      
      psychoJS.window.callOnFlip(function(){ audioStim.play(); });  // screen flip
      audioStim.status = PsychoJS.Status.STARTED;
    }
    if (t >= (audioStim.getDuration() + audioStim.tStart)     && audioStim.status === PsychoJS.Status.STARTED) {
      audioStim.stop();  // stop the sound (if longer than duration)
      audioStim.status = PsychoJS.Status.FINISHED;
    }
    // Run 'Each Frame' code from end_trial
    if ((audioStim.status === PsychoJS.Status.FINISHED)) {
        continueRoutine = false;
    }
    
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of trialComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function trialRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'trial' ---
    for (const thisComponent of trialComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    audioStim.stop();  // ensure sound has stopped at end of routine
    // the Routine "trial" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var recall_instructComponents;
function recall_instructRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'recall_instruct' ---
    t = 0;
    recall_instructClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    // setup some python lists for storing info about the mouse_recall_ins
    mouse_recall_ins.clicked_name = [];
    gotValidClick = false; // until a click is received
    // keep track of which components have finished
    recall_instructComponents = [];
    recall_instructComponents.push(image_bg_trial_3);
    recall_instructComponents.push(image_recall_ins);
    recall_instructComponents.push(image_next_9);
    recall_instructComponents.push(mouse_recall_ins);
    
    for (const thisComponent of recall_instructComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function recall_instructRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'recall_instruct' ---
    // get current time
    t = recall_instructClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *image_bg_trial_3* updates
    if (t >= 0.0 && image_bg_trial_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_bg_trial_3.tStart = t;  // (not accounting for frame time here)
      image_bg_trial_3.frameNStart = frameN;  // exact frame index
      
      image_bg_trial_3.setAutoDraw(true);
    }

    
    // *image_recall_ins* updates
    if (t >= 0.0 && image_recall_ins.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_recall_ins.tStart = t;  // (not accounting for frame time here)
      image_recall_ins.frameNStart = frameN;  // exact frame index
      
      image_recall_ins.setAutoDraw(true);
    }

    
    // *image_next_9* updates
    if (t >= 0.0 && image_next_9.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_next_9.tStart = t;  // (not accounting for frame time here)
      image_next_9.frameNStart = frameN;  // exact frame index
      
      image_next_9.setAutoDraw(true);
    }

    // *mouse_recall_ins* updates
    if (t >= 0.0 && mouse_recall_ins.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      mouse_recall_ins.tStart = t;  // (not accounting for frame time here)
      mouse_recall_ins.frameNStart = frameN;  // exact frame index
      
      mouse_recall_ins.status = PsychoJS.Status.STARTED;
      mouse_recall_ins.mouseClock.reset();
      prevButtonState = mouse_recall_ins.getPressed();  // if button is down already this ISN'T a new click
      }
    if (mouse_recall_ins.status === PsychoJS.Status.STARTED) {  // only update if started and not finished!
      _mouseButtons = mouse_recall_ins.getPressed();
      if (!_mouseButtons.every( (e,i,) => (e == prevButtonState[i]) )) { // button state changed?
        prevButtonState = _mouseButtons;
        if (_mouseButtons.reduce( (e, acc) => (e+acc) ) > 0) { // state changed to a new click
          // check if the mouse was inside our 'clickable' objects
          gotValidClick = false;
          for (const obj of [image_next_9]) {
            if (obj.contains(mouse_recall_ins)) {
              gotValidClick = true;
              mouse_recall_ins.clicked_name.push(obj.name)
            }
          }
          if (gotValidClick === true) { // abort routine on response
            continueRoutine = false;
          }
        }
      }
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of recall_instructComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function recall_instructRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'recall_instruct' ---
    for (const thisComponent of recall_instructComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // store data for psychoJS.experiment (ExperimentHandler)
    _mouseXYs = mouse_recall_ins.getPos();
    _mouseButtons = mouse_recall_ins.getPressed();
    psychoJS.experiment.addData('mouse_recall_ins.x', _mouseXYs[0]);
    psychoJS.experiment.addData('mouse_recall_ins.y', _mouseXYs[1]);
    psychoJS.experiment.addData('mouse_recall_ins.leftButton', _mouseButtons[0]);
    psychoJS.experiment.addData('mouse_recall_ins.midButton', _mouseButtons[1]);
    psychoJS.experiment.addData('mouse_recall_ins.rightButton', _mouseButtons[2]);
    if (mouse_recall_ins.clicked_name.length > 0) {
      psychoJS.experiment.addData('mouse_recall_ins.clicked_name', mouse_recall_ins.clicked_name[0]);}
    // the Routine "recall_instruct" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var round1Components;
function round1RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'round1' ---
    t = 0;
    round1Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(1.500000);
    // update component parameters for each repeat
    // keep track of which components have finished
    round1Components = [];
    round1Components.push(image_bg_trial_4);
    round1Components.push(image_round1);
    
    for (const thisComponent of round1Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


var frameRemains;
function round1RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'round1' ---
    // get current time
    t = round1Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *image_bg_trial_4* updates
    if (t >= 0.0 && image_bg_trial_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_bg_trial_4.tStart = t;  // (not accounting for frame time here)
      image_bg_trial_4.frameNStart = frameN;  // exact frame index
      
      image_bg_trial_4.setAutoDraw(true);
    }

    frameRemains = 0.0 + 1.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (image_bg_trial_4.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      image_bg_trial_4.setAutoDraw(false);
    }
    
    // *image_round1* updates
    if (t >= 0.0 && image_round1.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_round1.tStart = t;  // (not accounting for frame time here)
      image_round1.frameNStart = frameN;  // exact frame index
      
      image_round1.setAutoDraw(true);
    }

    frameRemains = 0.0 + 1.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (image_round1.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      image_round1.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of round1Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function round1RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'round1' ---
    for (const thisComponent of round1Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var clickables;
var clicked_things;
var clicked_list;
var recall1Components;
function recall1RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'recall1' ---
    t = 0;
    recall1Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    // Run 'Begin Routine' code from code_3
    clickables = [baby, fire, book, flag, sea, water, metal, child, table, shoes];
    clicked_things = "";
    clicked_list = [];
    
    // setup some python lists for storing info about the mouse_recall1
    // current position of the mouse:
    mouse_recall1.x = [];
    mouse_recall1.y = [];
    mouse_recall1.leftButton = [];
    mouse_recall1.midButton = [];
    mouse_recall1.rightButton = [];
    mouse_recall1.time = [];
    mouse_recall1.clicked_name = [];
    gotValidClick = false; // until a click is received
    // keep track of which components have finished
    recall1Components = [];
    recall1Components.push(image_bg_words_2);
    recall1Components.push(baby);
    recall1Components.push(flag);
    recall1Components.push(water);
    recall1Components.push(book);
    recall1Components.push(fire);
    recall1Components.push(sea);
    recall1Components.push(metal);
    recall1Components.push(child);
    recall1Components.push(table);
    recall1Components.push(shoes);
    recall1Components.push(image_next_6);
    recall1Components.push(mouse_recall1);
    
    for (const thisComponent of recall1Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function recall1RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'recall1' ---
    // get current time
    t = recall1Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // Run 'Each Frame' code from code_3
    for (var clickable, _pj_c = 0, _pj_a = clickables, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        clickable = _pj_a[_pj_c];
        if (mouse_recall1.isPressedIn(clickable)) {
            clickable.setOpacity(0.5);
            clicked_things = clickable.name;
            clicked_list.push(clicked_things);
        }
    }
    if (mouse_recall1.isPressedIn(image_next_6)) {
        continueRoutine = false;
    }
    
    
    // *image_bg_words_2* updates
    if (t >= 0.0 && image_bg_words_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_bg_words_2.tStart = t;  // (not accounting for frame time here)
      image_bg_words_2.frameNStart = frameN;  // exact frame index
      
      image_bg_words_2.setAutoDraw(true);
    }

    
    // *baby* updates
    if (t >= 0.0 && baby.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      baby.tStart = t;  // (not accounting for frame time here)
      baby.frameNStart = frameN;  // exact frame index
      
      baby.setAutoDraw(true);
    }

    
    // *flag* updates
    if (t >= 0.0 && flag.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      flag.tStart = t;  // (not accounting for frame time here)
      flag.frameNStart = frameN;  // exact frame index
      
      flag.setAutoDraw(true);
    }

    
    // *water* updates
    if (t >= 0.0 && water.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      water.tStart = t;  // (not accounting for frame time here)
      water.frameNStart = frameN;  // exact frame index
      
      water.setAutoDraw(true);
    }

    
    // *book* updates
    if (t >= 0.0 && book.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      book.tStart = t;  // (not accounting for frame time here)
      book.frameNStart = frameN;  // exact frame index
      
      book.setAutoDraw(true);
    }

    
    // *fire* updates
    if (t >= 0.0 && fire.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      fire.tStart = t;  // (not accounting for frame time here)
      fire.frameNStart = frameN;  // exact frame index
      
      fire.setAutoDraw(true);
    }

    
    // *sea* updates
    if (t >= 0.0 && sea.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      sea.tStart = t;  // (not accounting for frame time here)
      sea.frameNStart = frameN;  // exact frame index
      
      sea.setAutoDraw(true);
    }

    
    // *metal* updates
    if (t >= 0.0 && metal.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      metal.tStart = t;  // (not accounting for frame time here)
      metal.frameNStart = frameN;  // exact frame index
      
      metal.setAutoDraw(true);
    }

    
    // *child* updates
    if (t >= 0.0 && child.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      child.tStart = t;  // (not accounting for frame time here)
      child.frameNStart = frameN;  // exact frame index
      
      child.setAutoDraw(true);
    }

    
    // *table* updates
    if (t >= 0.0 && table.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      table.tStart = t;  // (not accounting for frame time here)
      table.frameNStart = frameN;  // exact frame index
      
      table.setAutoDraw(true);
    }

    
    // *shoes* updates
    if (t >= 0.0 && shoes.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      shoes.tStart = t;  // (not accounting for frame time here)
      shoes.frameNStart = frameN;  // exact frame index
      
      shoes.setAutoDraw(true);
    }

    
    // *image_next_6* updates
    if (t >= 0 && image_next_6.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_next_6.tStart = t;  // (not accounting for frame time here)
      image_next_6.frameNStart = frameN;  // exact frame index
      
      image_next_6.setAutoDraw(true);
    }

    // *mouse_recall1* updates
    if (t >= 0.0 && mouse_recall1.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      mouse_recall1.tStart = t;  // (not accounting for frame time here)
      mouse_recall1.frameNStart = frameN;  // exact frame index
      
      mouse_recall1.status = PsychoJS.Status.STARTED;
      mouse_recall1.mouseClock.reset();
      prevButtonState = mouse_recall1.getPressed();  // if button is down already this ISN'T a new click
      }
    if (mouse_recall1.status === PsychoJS.Status.STARTED) {  // only update if started and not finished!
      _mouseButtons = mouse_recall1.getPressed();
      if (!_mouseButtons.every( (e,i,) => (e == prevButtonState[i]) )) { // button state changed?
        prevButtonState = _mouseButtons;
        if (_mouseButtons.reduce( (e, acc) => (e+acc) ) > 0) { // state changed to a new click
          // check if the mouse was inside our 'clickable' objects
          gotValidClick = false;
          for (const obj of [image_next_6, baby, fire, book, flag, sea, water, metal, child, table, shoes]) {
            if (obj.contains(mouse_recall1)) {
              gotValidClick = true;
              mouse_recall1.clicked_name.push(obj.name)
            }
          }
          if (gotValidClick === true) { 
            _mouseXYs = mouse_recall1.getPos();
            mouse_recall1.x.push(_mouseXYs[0]);
            mouse_recall1.y.push(_mouseXYs[1]);
            mouse_recall1.leftButton.push(_mouseButtons[0]);
            mouse_recall1.midButton.push(_mouseButtons[1]);
            mouse_recall1.rightButton.push(_mouseButtons[2]);
            mouse_recall1.time.push(mouse_recall1.mouseClock.getTime());
          }
        }
      }
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of recall1Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


var _pj;
var main_clicked;
function recall1RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'recall1' ---
    for (const thisComponent of recall1Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Run 'End Routine' code from code_3
    var _pj;
    function _pj_snippets(container) {
        function in_es6(left, right) {
            if (((right instanceof Array) || ((typeof right) === "string"))) {
                return (right.indexOf(left) > (- 1));
            } else {
                if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                    return right.has(left);
                } else {
                    return (left in right);
                }
            }
        }
        container["in_es6"] = in_es6;
        return container;
    }
    _pj = {};
    _pj_snippets(_pj);
    main_clicked = [];
    for (var i, _pj_c = 0, _pj_a = clicked_list, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        i = _pj_a[_pj_c];
        if ((! _pj.in_es6(i, main_clicked))) {
            main_clicked.push(i);
        }
    }
    console.log(main_clicked);
    
    // store data for psychoJS.experiment (ExperimentHandler)
    psychoJS.experiment.addData('mouse_recall1.x', mouse_recall1.x);
    psychoJS.experiment.addData('mouse_recall1.y', mouse_recall1.y);
    psychoJS.experiment.addData('mouse_recall1.leftButton', mouse_recall1.leftButton);
    psychoJS.experiment.addData('mouse_recall1.midButton', mouse_recall1.midButton);
    psychoJS.experiment.addData('mouse_recall1.rightButton', mouse_recall1.rightButton);
    psychoJS.experiment.addData('mouse_recall1.time', mouse_recall1.time);
    psychoJS.experiment.addData('mouse_recall1.clicked_name', mouse_recall1.clicked_name);
    
    // the Routine "recall1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var resultsComponents;
function resultsRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'results' ---
    t = 0;
    resultsClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    text.setText((((("The words presented were " + presented_words) + "\n\n") + "The words you recalled were ") + main_clicked.toString()));
    // setup some python lists for storing info about the mouse_2
    // current position of the mouse:
    mouse_2.x = [];
    mouse_2.y = [];
    mouse_2.leftButton = [];
    mouse_2.midButton = [];
    mouse_2.rightButton = [];
    mouse_2.time = [];
    mouse_2.clicked_name = [];
    gotValidClick = false; // until a click is received
    // keep track of which components have finished
    resultsComponents = [];
    resultsComponents.push(image_bg_TR_2);
    resultsComponents.push(text);
    resultsComponents.push(image_next_4);
    resultsComponents.push(mouse_2);
    
    for (const thisComponent of resultsComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function resultsRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'results' ---
    // get current time
    t = resultsClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *image_bg_TR_2* updates
    if (t >= 0.0 && image_bg_TR_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_bg_TR_2.tStart = t;  // (not accounting for frame time here)
      image_bg_TR_2.frameNStart = frameN;  // exact frame index
      
      image_bg_TR_2.setAutoDraw(true);
    }

    
    // *text* updates
    if (t >= 0.0 && text.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text.tStart = t;  // (not accounting for frame time here)
      text.frameNStart = frameN;  // exact frame index
      
      text.setAutoDraw(true);
    }

    
    // *image_next_4* updates
    if (t >= 0.0 && image_next_4.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_next_4.tStart = t;  // (not accounting for frame time here)
      image_next_4.frameNStart = frameN;  // exact frame index
      
      image_next_4.setAutoDraw(true);
    }

    // *mouse_2* updates
    if (t >= 0.0 && mouse_2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      mouse_2.tStart = t;  // (not accounting for frame time here)
      mouse_2.frameNStart = frameN;  // exact frame index
      
      mouse_2.status = PsychoJS.Status.STARTED;
      mouse_2.mouseClock.reset();
      prevButtonState = mouse_2.getPressed();  // if button is down already this ISN'T a new click
      }
    if (mouse_2.status === PsychoJS.Status.STARTED) {  // only update if started and not finished!
      _mouseButtons = mouse_2.getPressed();
      if (!_mouseButtons.every( (e,i,) => (e == prevButtonState[i]) )) { // button state changed?
        prevButtonState = _mouseButtons;
        if (_mouseButtons.reduce( (e, acc) => (e+acc) ) > 0) { // state changed to a new click
          // check if the mouse was inside our 'clickable' objects
          gotValidClick = false;
          for (const obj of [image_next_4]) {
            if (obj.contains(mouse_2)) {
              gotValidClick = true;
              mouse_2.clicked_name.push(obj.name)
            }
          }
          if (gotValidClick === true) { 
            _mouseXYs = mouse_2.getPos();
            mouse_2.x.push(_mouseXYs[0]);
            mouse_2.y.push(_mouseXYs[1]);
            mouse_2.leftButton.push(_mouseButtons[0]);
            mouse_2.midButton.push(_mouseButtons[1]);
            mouse_2.rightButton.push(_mouseButtons[2]);
            mouse_2.time.push(mouse_2.mouseClock.getTime());
          }
          if (gotValidClick === true) { // abort routine on response
            continueRoutine = false;
          }
        }
      }
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of resultsComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function resultsRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'results' ---
    for (const thisComponent of resultsComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // store data for psychoJS.experiment (ExperimentHandler)
    if (mouse_2.x) {  psychoJS.experiment.addData('mouse_2.x', mouse_2.x[0])};
    if (mouse_2.y) {  psychoJS.experiment.addData('mouse_2.y', mouse_2.y[0])};
    if (mouse_2.leftButton) {  psychoJS.experiment.addData('mouse_2.leftButton', mouse_2.leftButton[0])};
    if (mouse_2.midButton) {  psychoJS.experiment.addData('mouse_2.midButton', mouse_2.midButton[0])};
    if (mouse_2.rightButton) {  psychoJS.experiment.addData('mouse_2.rightButton', mouse_2.rightButton[0])};
    if (mouse_2.time) {  psychoJS.experiment.addData('mouse_2.time', mouse_2.time[0])};
    if (mouse_2.clicked_name) {  psychoJS.experiment.addData('mouse_2.clicked_name', mouse_2.clicked_name[0])};
    
    // the Routine "results" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var round2Components;
function round2RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'round2' ---
    t = 0;
    round2Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(1.500000);
    // update component parameters for each repeat
    // keep track of which components have finished
    round2Components = [];
    round2Components.push(image_bg_trial_5);
    round2Components.push(image_round2);
    
    for (const thisComponent of round2Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function round2RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'round2' ---
    // get current time
    t = round2Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *image_bg_trial_5* updates
    if (t >= 0.0 && image_bg_trial_5.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_bg_trial_5.tStart = t;  // (not accounting for frame time here)
      image_bg_trial_5.frameNStart = frameN;  // exact frame index
      
      image_bg_trial_5.setAutoDraw(true);
    }

    frameRemains = 0.0 + 1.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (image_bg_trial_5.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      image_bg_trial_5.setAutoDraw(false);
    }
    
    // *image_round2* updates
    if (t >= 0.0 && image_round2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_round2.tStart = t;  // (not accounting for frame time here)
      image_round2.frameNStart = frameN;  // exact frame index
      
      image_round2.setAutoDraw(true);
    }

    frameRemains = 0.0 + 1.5 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (image_round2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      image_round2.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of round2Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function round2RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'round2' ---
    for (const thisComponent of round2Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var clickables2;
var clicked_things2;
var clicked_list2;
var recall2Components;
function recall2RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'recall2' ---
    t = 0;
    recall2Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    // Run 'Begin Routine' code from code_4
    clickables2 = [earth, blood, house, hotel, ball, sky, rock, gold, tree, home];
    clicked_things2 = "";
    clicked_list2 = [];
    
    // setup some python lists for storing info about the mouse_recall2
    // current position of the mouse:
    mouse_recall2.x = [];
    mouse_recall2.y = [];
    mouse_recall2.leftButton = [];
    mouse_recall2.midButton = [];
    mouse_recall2.rightButton = [];
    mouse_recall2.time = [];
    mouse_recall2.clicked_name = [];
    gotValidClick = false; // until a click is received
    // keep track of which components have finished
    recall2Components = [];
    recall2Components.push(image_bg_words_3);
    recall2Components.push(earth);
    recall2Components.push(blood);
    recall2Components.push(house);
    recall2Components.push(hotel);
    recall2Components.push(ball);
    recall2Components.push(sky);
    recall2Components.push(rock);
    recall2Components.push(gold);
    recall2Components.push(tree);
    recall2Components.push(home);
    recall2Components.push(image_next_7);
    recall2Components.push(mouse_recall2);
    
    for (const thisComponent of recall2Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function recall2RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'recall2' ---
    // get current time
    t = recall2Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    // Run 'Each Frame' code from code_4
    for (var clickable2, _pj_c = 0, _pj_a = clickables2, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        clickable2 = _pj_a[_pj_c];
        if (mouse_recall2.isPressedIn(clickable2)) {
            clickable2.setOpacity(0.5);
            clicked_things2 = clickable2.name;
            clicked_list2.push(clicked_things2);
        }
    }
    if (mouse_recall2.isPressedIn(image_next_7)) {
        continueRoutine = false;
    }
    
    
    // *image_bg_words_3* updates
    if (t >= 0.0 && image_bg_words_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_bg_words_3.tStart = t;  // (not accounting for frame time here)
      image_bg_words_3.frameNStart = frameN;  // exact frame index
      
      image_bg_words_3.setAutoDraw(true);
    }

    
    // *earth* updates
    if (t >= 0.0 && earth.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      earth.tStart = t;  // (not accounting for frame time here)
      earth.frameNStart = frameN;  // exact frame index
      
      earth.setAutoDraw(true);
    }

    
    // *blood* updates
    if (t >= 0.0 && blood.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      blood.tStart = t;  // (not accounting for frame time here)
      blood.frameNStart = frameN;  // exact frame index
      
      blood.setAutoDraw(true);
    }

    
    // *house* updates
    if (t >= 0.0 && house.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      house.tStart = t;  // (not accounting for frame time here)
      house.frameNStart = frameN;  // exact frame index
      
      house.setAutoDraw(true);
    }

    
    // *hotel* updates
    if (t >= 0.0 && hotel.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      hotel.tStart = t;  // (not accounting for frame time here)
      hotel.frameNStart = frameN;  // exact frame index
      
      hotel.setAutoDraw(true);
    }

    
    // *ball* updates
    if (t >= 0.0 && ball.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      ball.tStart = t;  // (not accounting for frame time here)
      ball.frameNStart = frameN;  // exact frame index
      
      ball.setAutoDraw(true);
    }

    
    // *sky* updates
    if (t >= 0.0 && sky.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      sky.tStart = t;  // (not accounting for frame time here)
      sky.frameNStart = frameN;  // exact frame index
      
      sky.setAutoDraw(true);
    }

    
    // *rock* updates
    if (t >= 0.0 && rock.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      rock.tStart = t;  // (not accounting for frame time here)
      rock.frameNStart = frameN;  // exact frame index
      
      rock.setAutoDraw(true);
    }

    
    // *gold* updates
    if (t >= 0.0 && gold.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      gold.tStart = t;  // (not accounting for frame time here)
      gold.frameNStart = frameN;  // exact frame index
      
      gold.setAutoDraw(true);
    }

    
    // *tree* updates
    if (t >= 0.0 && tree.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      tree.tStart = t;  // (not accounting for frame time here)
      tree.frameNStart = frameN;  // exact frame index
      
      tree.setAutoDraw(true);
    }

    
    // *home* updates
    if (t >= 0.0 && home.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      home.tStart = t;  // (not accounting for frame time here)
      home.frameNStart = frameN;  // exact frame index
      
      home.setAutoDraw(true);
    }

    
    // *image_next_7* updates
    if (t >= 0 && image_next_7.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_next_7.tStart = t;  // (not accounting for frame time here)
      image_next_7.frameNStart = frameN;  // exact frame index
      
      image_next_7.setAutoDraw(true);
    }

    // *mouse_recall2* updates
    if (t >= 0.0 && mouse_recall2.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      mouse_recall2.tStart = t;  // (not accounting for frame time here)
      mouse_recall2.frameNStart = frameN;  // exact frame index
      
      mouse_recall2.status = PsychoJS.Status.STARTED;
      mouse_recall2.mouseClock.reset();
      prevButtonState = mouse_recall2.getPressed();  // if button is down already this ISN'T a new click
      }
    if (mouse_recall2.status === PsychoJS.Status.STARTED) {  // only update if started and not finished!
      _mouseButtons = mouse_recall2.getPressed();
      if (!_mouseButtons.every( (e,i,) => (e == prevButtonState[i]) )) { // button state changed?
        prevButtonState = _mouseButtons;
        if (_mouseButtons.reduce( (e, acc) => (e+acc) ) > 0) { // state changed to a new click
          // check if the mouse was inside our 'clickable' objects
          gotValidClick = false;
          for (const obj of [image_next_7, earth, blood, house, hotel, ball, sky, rock, gold, tree, home]) {
            if (obj.contains(mouse_recall2)) {
              gotValidClick = true;
              mouse_recall2.clicked_name.push(obj.name)
            }
          }
          if (gotValidClick === true) { 
            _mouseXYs = mouse_recall2.getPos();
            mouse_recall2.x.push(_mouseXYs[0]);
            mouse_recall2.y.push(_mouseXYs[1]);
            mouse_recall2.leftButton.push(_mouseButtons[0]);
            mouse_recall2.midButton.push(_mouseButtons[1]);
            mouse_recall2.rightButton.push(_mouseButtons[2]);
            mouse_recall2.time.push(mouse_recall2.mouseClock.getTime());
          }
        }
      }
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of recall2Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


var main_clicked2;
function recall2RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'recall2' ---
    for (const thisComponent of recall2Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Run 'End Routine' code from code_4
    var _pj;
    function _pj_snippets(container) {
        function in_es6(left, right) {
            if (((right instanceof Array) || ((typeof right) === "string"))) {
                return (right.indexOf(left) > (- 1));
            } else {
                if (((right instanceof Map) || (right instanceof Set) || (right instanceof WeakMap) || (right instanceof WeakSet))) {
                    return right.has(left);
                } else {
                    return (left in right);
                }
            }
        }
        container["in_es6"] = in_es6;
        return container;
    }
    _pj = {};
    _pj_snippets(_pj);
    main_clicked2 = [];
    for (var i2, _pj_c = 0, _pj_a = clicked_list2, _pj_b = _pj_a.length; (_pj_c < _pj_b); _pj_c += 1) {
        i2 = _pj_a[_pj_c];
        if ((! _pj.in_es6(i2, main_clicked2))) {
            main_clicked2.push(i2);
        }
    }
    console.log(main_clicked2);
    
    // store data for psychoJS.experiment (ExperimentHandler)
    psychoJS.experiment.addData('mouse_recall2.x', mouse_recall2.x);
    psychoJS.experiment.addData('mouse_recall2.y', mouse_recall2.y);
    psychoJS.experiment.addData('mouse_recall2.leftButton', mouse_recall2.leftButton);
    psychoJS.experiment.addData('mouse_recall2.midButton', mouse_recall2.midButton);
    psychoJS.experiment.addData('mouse_recall2.rightButton', mouse_recall2.rightButton);
    psychoJS.experiment.addData('mouse_recall2.time', mouse_recall2.time);
    psychoJS.experiment.addData('mouse_recall2.clicked_name', mouse_recall2.clicked_name);
    
    // the Routine "recall2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var results_2Components;
function results_2RoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'results_2' ---
    t = 0;
    results_2Clock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    // update component parameters for each repeat
    text_3.setText((((("The words presented were " + presented_words2) + "\n\n") + "The words you recalled were ") + main_clicked2.toString()));
    // setup some python lists for storing info about the mouse_3
    // current position of the mouse:
    mouse_3.x = [];
    mouse_3.y = [];
    mouse_3.leftButton = [];
    mouse_3.midButton = [];
    mouse_3.rightButton = [];
    mouse_3.time = [];
    mouse_3.clicked_name = [];
    gotValidClick = false; // until a click is received
    // keep track of which components have finished
    results_2Components = [];
    results_2Components.push(image_bg_TR_3);
    results_2Components.push(text_3);
    results_2Components.push(image_next_8);
    results_2Components.push(mouse_3);
    
    for (const thisComponent of results_2Components)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function results_2RoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'results_2' ---
    // get current time
    t = results_2Clock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *image_bg_TR_3* updates
    if (t >= 0.0 && image_bg_TR_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_bg_TR_3.tStart = t;  // (not accounting for frame time here)
      image_bg_TR_3.frameNStart = frameN;  // exact frame index
      
      image_bg_TR_3.setAutoDraw(true);
    }

    
    // *text_3* updates
    if (t >= 0.0 && text_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      text_3.tStart = t;  // (not accounting for frame time here)
      text_3.frameNStart = frameN;  // exact frame index
      
      text_3.setAutoDraw(true);
    }

    
    // *image_next_8* updates
    if (t >= 0.0 && image_next_8.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_next_8.tStart = t;  // (not accounting for frame time here)
      image_next_8.frameNStart = frameN;  // exact frame index
      
      image_next_8.setAutoDraw(true);
    }

    // *mouse_3* updates
    if (t >= 0.0 && mouse_3.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      mouse_3.tStart = t;  // (not accounting for frame time here)
      mouse_3.frameNStart = frameN;  // exact frame index
      
      mouse_3.status = PsychoJS.Status.STARTED;
      mouse_3.mouseClock.reset();
      prevButtonState = mouse_3.getPressed();  // if button is down already this ISN'T a new click
      }
    if (mouse_3.status === PsychoJS.Status.STARTED) {  // only update if started and not finished!
      _mouseButtons = mouse_3.getPressed();
      if (!_mouseButtons.every( (e,i,) => (e == prevButtonState[i]) )) { // button state changed?
        prevButtonState = _mouseButtons;
        if (_mouseButtons.reduce( (e, acc) => (e+acc) ) > 0) { // state changed to a new click
          // check if the mouse was inside our 'clickable' objects
          gotValidClick = false;
          for (const obj of [image_next_8]) {
            if (obj.contains(mouse_3)) {
              gotValidClick = true;
              mouse_3.clicked_name.push(obj.name)
            }
          }
          if (gotValidClick === true) { 
            _mouseXYs = mouse_3.getPos();
            mouse_3.x.push(_mouseXYs[0]);
            mouse_3.y.push(_mouseXYs[1]);
            mouse_3.leftButton.push(_mouseButtons[0]);
            mouse_3.midButton.push(_mouseButtons[1]);
            mouse_3.rightButton.push(_mouseButtons[2]);
            mouse_3.time.push(mouse_3.mouseClock.getTime());
          }
          if (gotValidClick === true) { // abort routine on response
            continueRoutine = false;
          }
        }
      }
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of results_2Components)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function results_2RoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'results_2' ---
    for (const thisComponent of results_2Components) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // store data for psychoJS.experiment (ExperimentHandler)
    if (mouse_3.x) {  psychoJS.experiment.addData('mouse_3.x', mouse_3.x[0])};
    if (mouse_3.y) {  psychoJS.experiment.addData('mouse_3.y', mouse_3.y[0])};
    if (mouse_3.leftButton) {  psychoJS.experiment.addData('mouse_3.leftButton', mouse_3.leftButton[0])};
    if (mouse_3.midButton) {  psychoJS.experiment.addData('mouse_3.midButton', mouse_3.midButton[0])};
    if (mouse_3.rightButton) {  psychoJS.experiment.addData('mouse_3.rightButton', mouse_3.rightButton[0])};
    if (mouse_3.time) {  psychoJS.experiment.addData('mouse_3.time', mouse_3.time[0])};
    if (mouse_3.clicked_name) {  psychoJS.experiment.addData('mouse_3.clicked_name', mouse_3.clicked_name[0])};
    
    // the Routine "results_2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset();
    
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


var endComponents;
function endRoutineBegin(snapshot) {
  return async function () {
    TrialHandler.fromSnapshot(snapshot); // ensure that .thisN vals are up to date
    
    //--- Prepare to start Routine 'end' ---
    t = 0;
    endClock.reset(); // clock
    frameN = -1;
    continueRoutine = true; // until we're told otherwise
    routineTimer.add(3.000000);
    // update component parameters for each repeat
    // keep track of which components have finished
    endComponents = [];
    endComponents.push(image_bg_trial_6);
    endComponents.push(image_branding);
    
    for (const thisComponent of endComponents)
      if ('status' in thisComponent)
        thisComponent.status = PsychoJS.Status.NOT_STARTED;
    return Scheduler.Event.NEXT;
  }
}


function endRoutineEachFrame() {
  return async function () {
    //--- Loop for each frame of Routine 'end' ---
    // get current time
    t = endClock.getTime();
    frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
    // update/draw components on each frame
    
    // *image_bg_trial_6* updates
    if (t >= 0.0 && image_bg_trial_6.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_bg_trial_6.tStart = t;  // (not accounting for frame time here)
      image_bg_trial_6.frameNStart = frameN;  // exact frame index
      
      image_bg_trial_6.setAutoDraw(true);
    }

    frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (image_bg_trial_6.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      image_bg_trial_6.setAutoDraw(false);
    }
    
    // *image_branding* updates
    if (t >= 0.0 && image_branding.status === PsychoJS.Status.NOT_STARTED) {
      // keep track of start time/frame for later
      image_branding.tStart = t;  // (not accounting for frame time here)
      image_branding.frameNStart = frameN;  // exact frame index
      
      image_branding.setAutoDraw(true);
    }

    frameRemains = 0.0 + 3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
    if (image_branding.status === PsychoJS.Status.STARTED && t >= frameRemains) {
      image_branding.setAutoDraw(false);
    }
    // check for quit (typically the Esc key)
    if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
      return quitPsychoJS('The [Escape] key was pressed. Goodbye!', false);
    }
    
    // check if the Routine should terminate
    if (!continueRoutine) {  // a component has requested a forced-end of Routine
      return Scheduler.Event.NEXT;
    }
    
    continueRoutine = false;  // reverts to True if at least one component still running
    for (const thisComponent of endComponents)
      if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
        continueRoutine = true;
        break;
      }
    
    // refresh the screen if continuing
    if (continueRoutine && routineTimer.getTime() > 0) {
      return Scheduler.Event.FLIP_REPEAT;
    } else {
      return Scheduler.Event.NEXT;
    }
  };
}


function endRoutineEnd(snapshot) {
  return async function () {
    //--- Ending Routine 'end' ---
    for (const thisComponent of endComponents) {
      if (typeof thisComponent.setAutoDraw === 'function') {
        thisComponent.setAutoDraw(false);
      }
    }
    // Routines running outside a loop should always advance the datafile row
    if (currentLoop === psychoJS.experiment) {
      psychoJS.experiment.nextEntry(snapshot);
    }
    return Scheduler.Event.NEXT;
  }
}


function importConditions(currentLoop) {
  return async function () {
    psychoJS.importAttributes(currentLoop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


async function quitPsychoJS(message, isCompleted) {
  // Check for and save orphaned data
  if (psychoJS.experiment.isEntryEmpty()) {
    psychoJS.experiment.nextEntry();
  }
  
  
  
  
  
  
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});
  
  return Scheduler.Event.QUIT;
}

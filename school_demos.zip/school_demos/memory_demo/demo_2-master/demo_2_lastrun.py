﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2022.2.0),
    on July 07, 2022, at 15:56
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
prefs.hardware['audioLib'] = 'ptb'
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

import psychopy.iohub as io
from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)
# Store info about the experiment session
psychopyVersion = '2022.2.0'
expName = 'pre_task'  # from the Builder filename that created this script
expInfo = {
    'participant': '',
    'session': '001',
}
# --- Show participant info dialog --
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='C:\\Users\\suely\\OneDrive\\Desktop\\demos\\school demos\\primacy_recency\\demo_2_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# --- Setup the Window ---
win = visual.Window(
    size=[1920, 1080], fullscr=True, screen=1, 
    winType='pyglet', allowStencil=False,
    monitor='testMonitor', color='black', colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
win.mouseVisible = False
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess
# --- Setup input devices ---
ioConfig = {}

# Setup iohub keyboard
ioConfig['Keyboard'] = dict(use_keymap='psychopy')

ioSession = '1'
if 'session' in expInfo:
    ioSession = str(expInfo['session'])
ioServer = io.launchHubServer(window=win, **ioConfig)
eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard(backend='iohub')

# --- Initialize components for Routine "instructions" ---
image_bg_inst = visual.ImageStim(
    win=win,
    name='image_bg_inst', 
    image='stim/bg.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(1.8, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
image_ins = visual.ImageStim(
    win=win,
    name='image_ins', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=1.0,
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)
image_next = visual.ImageStim(
    win=win,
    name='image_next', 
    image='stim/next.png', mask=None, anchor='center',
    ori=0.0, pos=(0.375, -0.35), size=(0.2, 0.15),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-2.0)
mouse_inst = event.Mouse(win=win)
x, y = [None, None]
mouse_inst.mouseClock = core.Clock()

# --- Initialize components for Routine "trial" ---
image_bg_trial = visual.ImageStim(
    win=win,
    name='image_bg_trial', 
    image='stim/bg.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(1.8, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
image_hp = visual.ImageStim(
    win=win,
    name='image_hp', 
    image='stim/headphone.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(0.5, 0.5),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)
audioStim = sound.Sound('A', secs=-1, stereo=True, hamming=True,
    name='audioStim')
audioStim.setVolume(1.0)

# --- Initialize components for Routine "recall_instruct" ---
image_bg_trial_3 = visual.ImageStim(
    win=win,
    name='image_bg_trial_3', 
    image='stim/bg.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(1.8, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
image_recall_ins = visual.ImageStim(
    win=win,
    name='image_recall_ins', 
    image='stim/instructs/recall_ins.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(2.651*0.45, 0.45),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)
image_next_9 = visual.ImageStim(
    win=win,
    name='image_next_9', 
    image='stim/next.png', mask=None, anchor='center',
    ori=0.0, pos=(0.375, -0.35), size=(0.2, 0.15),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-2.0)
mouse_recall_ins = event.Mouse(win=win)
x, y = [None, None]
mouse_recall_ins.mouseClock = core.Clock()

# --- Initialize components for Routine "round1" ---
image_bg_trial_4 = visual.ImageStim(
    win=win,
    name='image_bg_trial_4', 
    image='stim/bg.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(1.8, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
image_round1 = visual.ImageStim(
    win=win,
    name='image_round1', 
    image='stim/instructs/round1.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(2.615*0.4, 0.4),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)

# --- Initialize components for Routine "recall1" ---
image_bg_words_2 = visual.ImageStim(
    win=win,
    name='image_bg_words_2', 
    image='stim/bg.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(1.8, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)
baby = visual.ImageStim(
    win=win,
    name='baby', 
    image='stim/recall_1/baby.png', mask=None, anchor='center',
    ori=0.0, pos=(-0.6, 0.175), size=(1.915*0.1, 0.1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-2.0)
flag = visual.ImageStim(
    win=win,
    name='flag', 
    image='stim/recall_1/flag.png', mask=None, anchor='center',
    ori=0.0, pos=(-0.2, 0.175), size=(1.915*0.1, 0.1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-3.0)
water = visual.ImageStim(
    win=win,
    name='water', 
    image='stim/recall_1/water.png', mask=None, anchor='center',
    ori=0.0, pos=(0.2, 0.175), size=(1.915*0.1, 0.1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-4.0)
book = visual.ImageStim(
    win=win,
    name='book', 
    image='stim/recall_1/book.png', mask=None, anchor='center',
    ori=0.0, pos=(-0.6, -0.175), size=(1.915*0.1, 0.1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-5.0)
fire = visual.ImageStim(
    win=win,
    name='fire', 
    image='stim/recall_1/fire.png', mask=None, anchor='center',
    ori=0.0, pos=(-0.6, 0), size=(1.915*0.1, 0.1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-6.0)
sea = visual.ImageStim(
    win=win,
    name='sea', 
    image='stim/recall_1/sea.png', mask=None, anchor='center',
    ori=0.0, pos=(-0.2, 0), size=(1.915*0.1, 0.1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-7.0)
metal = visual.ImageStim(
    win=win,
    name='metal', 
    image='stim/recall_1/metal.png', mask=None, anchor='center',
    ori=0.0, pos=(0.2, 0), size=(1.915*0.1, 0.1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-8.0)
child = visual.ImageStim(
    win=win,
    name='child', 
    image='stim/recall_1/child.png', mask=None, anchor='center',
    ori=0.0, pos=(0.6, 0), size=(1.915*0.1, 0.1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-9.0)
table = visual.ImageStim(
    win=win,
    name='table', 
    image='stim/recall_1/table.png', mask=None, anchor='center',
    ori=0.0, pos=(-0.2, -0.175), size=(1.915*0.1, 0.1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-10.0)
shoes = visual.ImageStim(
    win=win,
    name='shoes', 
    image='stim/recall_1/shoes.png', mask=None, anchor='center',
    ori=0.0, pos=(0.2, -0.175), size=(1.915*0.1, 0.1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-11.0)
image_next_6 = visual.ImageStim(
    win=win,
    name='image_next_6', 
    image='stim/next.png', mask=None, anchor='center',
    ori=0.0, pos=(0.375, -0.35), size=(0.2, 0.15),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-12.0)
mouse_recall1 = event.Mouse(win=win)
x, y = [None, None]
mouse_recall1.mouseClock = core.Clock()

# --- Initialize components for Routine "results" ---
image_bg_TR_2 = visual.ImageStim(
    win=win,
    name='image_bg_TR_2', 
    image='stim/bg.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(1.8, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
text = visual.TextStim(win=win, name='text',
    text='',
    font='Arial',
    pos=(0, 0), height=0.08, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
image_next_4 = visual.ImageStim(
    win=win,
    name='image_next_4', 
    image='stim/next.png', mask=None, anchor='center',
    ori=0.0, pos=(0.375, -0.35), size=(0.2, 0.15),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-2.0)
mouse_2 = event.Mouse(win=win)
x, y = [None, None]
mouse_2.mouseClock = core.Clock()

# --- Initialize components for Routine "round2" ---
image_bg_trial_5 = visual.ImageStim(
    win=win,
    name='image_bg_trial_5', 
    image='stim/bg.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(1.8, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
image_round2 = visual.ImageStim(
    win=win,
    name='image_round2', 
    image='stim/instructs/round2.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(2.615*0.4, 0.4),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)

# --- Initialize components for Routine "recall2" ---
image_bg_words_3 = visual.ImageStim(
    win=win,
    name='image_bg_words_3', 
    image='stim/bg.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(1.8, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)
earth = visual.ImageStim(
    win=win,
    name='earth', 
    image='stim/recall_2/earth.png', mask=None, anchor='center',
    ori=0.0, pos=(-0.6, 0.175), size=(1.915*0.1, 0.1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-2.0)
blood = visual.ImageStim(
    win=win,
    name='blood', 
    image='stim/recall_2/blood.png', mask=None, anchor='center',
    ori=0.0, pos=(-0.2, 0.175), size=(1.915*0.1, 0.1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-3.0)
house = visual.ImageStim(
    win=win,
    name='house', 
    image='stim/recall_2/house.png', mask=None, anchor='center',
    ori=0.0, pos=(0.2, 0.175), size=(1.915*0.1, 0.1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-4.0)
hotel = visual.ImageStim(
    win=win,
    name='hotel', 
    image='stim/recall_2/hotel.png', mask=None, anchor='center',
    ori=0.0, pos=(-0.6, -0.175), size=(1.915*0.1, 0.1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-5.0)
ball = visual.ImageStim(
    win=win,
    name='ball', 
    image='stim/recall_2/ball.png', mask=None, anchor='center',
    ori=0.0, pos=(-0.6, 0), size=(1.915*0.1, 0.1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-6.0)
sky = visual.ImageStim(
    win=win,
    name='sky', 
    image='stim/recall_2/sky.png', mask=None, anchor='center',
    ori=0.0, pos=(-0.2, 0), size=(1.915*0.1, 0.1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-7.0)
rock = visual.ImageStim(
    win=win,
    name='rock', 
    image='stim/recall_2/rock.png', mask=None, anchor='center',
    ori=0.0, pos=(0.2, 0), size=(1.915*0.1, 0.1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-8.0)
gold = visual.ImageStim(
    win=win,
    name='gold', 
    image='stim/recall_2/gold.png', mask=None, anchor='center',
    ori=0.0, pos=(0.6, 0), size=(1.915*0.1, 0.1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-9.0)
tree = visual.ImageStim(
    win=win,
    name='tree', 
    image='stim/recall_2/tree.png', mask=None, anchor='center',
    ori=0.0, pos=(-0.2, -0.175), size=(1.915*0.1, 0.1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-10.0)
home = visual.ImageStim(
    win=win,
    name='home', 
    image='stim/recall_2/home.png', mask=None, anchor='center',
    ori=0.0, pos=(0.2, -0.175), size=(1.915*0.1, 0.1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-11.0)
image_next_7 = visual.ImageStim(
    win=win,
    name='image_next_7', 
    image='stim/next.png', mask=None, anchor='center',
    ori=0.0, pos=(0.375, -0.35), size=(0.2, 0.15),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-12.0)
mouse_recall2 = event.Mouse(win=win)
x, y = [None, None]
mouse_recall2.mouseClock = core.Clock()

# --- Initialize components for Routine "results_2" ---
image_bg_TR_3 = visual.ImageStim(
    win=win,
    name='image_bg_TR_3', 
    image='stim/bg.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(1.8, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
text_3 = visual.TextStim(win=win, name='text_3',
    text='',
    font='Arial',
    pos=(0, 0), height=0.08, wrapWidth=None, ori=0.0, 
    color='white', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=-1.0);
image_next_8 = visual.ImageStim(
    win=win,
    name='image_next_8', 
    image='stim/next.png', mask=None, anchor='center',
    ori=0.0, pos=(0.375, -0.35), size=(0.2, 0.15),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-2.0)
mouse_3 = event.Mouse(win=win)
x, y = [None, None]
mouse_3.mouseClock = core.Clock()

# --- Initialize components for Routine "end" ---
image_bg_trial_6 = visual.ImageStim(
    win=win,
    name='image_bg_trial_6', 
    image='stim/bg.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(1.8, 1),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=0.0)
image_branding = visual.ImageStim(
    win=win,
    name='image_branding', 
    image='stim/branding.png', mask=None, anchor='center',
    ori=0.0, pos=(0, 0), size=(2.526*0.45, 0.45),
    color=[1,1,1], colorSpace='rgb', opacity=None,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-1.0)

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.Clock()  # to track time remaining of each (possibly non-slip) routine 

# set up handler to look after randomisation of conditions etc
instructLoop = data.TrialHandler(nReps=1.0, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('instruct_block.xlsx'),
    seed=None, name='instructLoop')
thisExp.addLoop(instructLoop)  # add the loop to the experiment
thisInstructLoop = instructLoop.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisInstructLoop.rgb)
if thisInstructLoop != None:
    for paramName in thisInstructLoop:
        exec('{} = thisInstructLoop[paramName]'.format(paramName))

for thisInstructLoop in instructLoop:
    currentLoop = instructLoop
    # abbreviate parameter names if possible (e.g. rgb = thisInstructLoop.rgb)
    if thisInstructLoop != None:
        for paramName in thisInstructLoop:
            exec('{} = thisInstructLoop[paramName]'.format(paramName))
    
    # --- Prepare to start Routine "instructions" ---
    continueRoutine = True
    # update component parameters for each repeat
    image_ins.setSize((img_size*0.5, 0.5))
    image_ins.setImage(ins_img)
    # setup some python lists for storing info about the mouse_inst
    mouse_inst.clicked_name = []
    gotValidClick = False  # until a click is received
    # keep track of which components have finished
    instructionsComponents = [image_bg_inst, image_ins, image_next, mouse_inst]
    for thisComponent in instructionsComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "instructions" ---
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *image_bg_inst* updates
        if image_bg_inst.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            image_bg_inst.frameNStart = frameN  # exact frame index
            image_bg_inst.tStart = t  # local t and not account for scr refresh
            image_bg_inst.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(image_bg_inst, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_bg_inst.started')
            image_bg_inst.setAutoDraw(True)
        
        # *image_ins* updates
        if image_ins.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            image_ins.frameNStart = frameN  # exact frame index
            image_ins.tStart = t  # local t and not account for scr refresh
            image_ins.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(image_ins, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_ins.started')
            image_ins.setAutoDraw(True)
        
        # *image_next* updates
        if image_next.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            image_next.frameNStart = frameN  # exact frame index
            image_next.tStart = t  # local t and not account for scr refresh
            image_next.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(image_next, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_next.started')
            image_next.setAutoDraw(True)
        # *mouse_inst* updates
        if mouse_inst.status == NOT_STARTED and t >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            mouse_inst.frameNStart = frameN  # exact frame index
            mouse_inst.tStart = t  # local t and not account for scr refresh
            mouse_inst.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(mouse_inst, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.addData('mouse_inst.started', t)
            mouse_inst.status = STARTED
            mouse_inst.mouseClock.reset()
            prevButtonState = mouse_inst.getPressed()  # if button is down already this ISN'T a new click
        if mouse_inst.status == STARTED:  # only update if started and not finished!
            buttons = mouse_inst.getPressed()
            if buttons != prevButtonState:  # button state changed?
                prevButtonState = buttons
                if sum(buttons) > 0:  # state changed to a new click
                    # check if the mouse was inside our 'clickable' objects
                    gotValidClick = False
                    try:
                        iter(image_next)
                        clickableList = image_next
                    except:
                        clickableList = [image_next]
                    for obj in clickableList:
                        if obj.contains(mouse_inst):
                            gotValidClick = True
                            mouse_inst.clicked_name.append(obj.name)
                    if gotValidClick:  
                        continueRoutine = False  # abort routine on response
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in instructionsComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "instructions" ---
    for thisComponent in instructionsComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store data for instructLoop (TrialHandler)
    x, y = mouse_inst.getPos()
    buttons = mouse_inst.getPressed()
    if sum(buttons):
        # check if the mouse was inside our 'clickable' objects
        gotValidClick = False
        try:
            iter(image_next)
            clickableList = image_next
        except:
            clickableList = [image_next]
        for obj in clickableList:
            if obj.contains(mouse_inst):
                gotValidClick = True
                mouse_inst.clicked_name.append(obj.name)
    instructLoop.addData('mouse_inst.x', x)
    instructLoop.addData('mouse_inst.y', y)
    instructLoop.addData('mouse_inst.leftButton', buttons[0])
    instructLoop.addData('mouse_inst.midButton', buttons[1])
    instructLoop.addData('mouse_inst.rightButton', buttons[2])
    if len(mouse_inst.clicked_name):
        instructLoop.addData('mouse_inst.clicked_name', mouse_inst.clicked_name[0])
    # the Routine "instructions" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
# completed 1.0 repeats of 'instructLoop'


# set up handler to look after randomisation of conditions etc
trials = data.TrialHandler(nReps=1.0, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('word_list.xlsx'),
    seed=None, name='trials')
thisExp.addLoop(trials)  # add the loop to the experiment
thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
if thisTrial != None:
    for paramName in thisTrial:
        exec('{} = thisTrial[paramName]'.format(paramName))

for thisTrial in trials:
    currentLoop = trials
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial:
            exec('{} = thisTrial[paramName]'.format(paramName))
    
    # --- Prepare to start Routine "trial" ---
    continueRoutine = True
    # update component parameters for each repeat
    audioStim.setSound(list_of_words, hamming=True)
    audioStim.setVolume(1.0, log=False)
    # keep track of which components have finished
    trialComponents = [image_bg_trial, image_hp, audioStim]
    for thisComponent in trialComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "trial" ---
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *image_bg_trial* updates
        if image_bg_trial.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            image_bg_trial.frameNStart = frameN  # exact frame index
            image_bg_trial.tStart = t  # local t and not account for scr refresh
            image_bg_trial.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(image_bg_trial, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_bg_trial.started')
            image_bg_trial.setAutoDraw(True)
        
        # *image_hp* updates
        if image_hp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            image_hp.frameNStart = frameN  # exact frame index
            image_hp.tStart = t  # local t and not account for scr refresh
            image_hp.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(image_hp, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_hp.started')
            image_hp.setAutoDraw(True)
        # start/stop audioStim
        if audioStim.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
            # keep track of start time/frame for later
            audioStim.frameNStart = frameN  # exact frame index
            audioStim.tStart = t  # local t and not account for scr refresh
            audioStim.tStartRefresh = tThisFlipGlobal  # on global time
            # add timestamp to datafile
            thisExp.addData('audioStim.started', tThisFlipGlobal)
            audioStim.play(when=win)  # sync with win flip
        # Run 'Each Frame' code from end_trial
        if audioStim.status == FINISHED:
            continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in trialComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "trial" ---
    for thisComponent in trialComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    audioStim.stop()  # ensure sound has stopped at end of routine
    # the Routine "trial" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1.0 repeats of 'trials'


# --- Prepare to start Routine "recall_instruct" ---
continueRoutine = True
# update component parameters for each repeat
# setup some python lists for storing info about the mouse_recall_ins
mouse_recall_ins.clicked_name = []
gotValidClick = False  # until a click is received
# keep track of which components have finished
recall_instructComponents = [image_bg_trial_3, image_recall_ins, image_next_9, mouse_recall_ins]
for thisComponent in recall_instructComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "recall_instruct" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_bg_trial_3* updates
    if image_bg_trial_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_bg_trial_3.frameNStart = frameN  # exact frame index
        image_bg_trial_3.tStart = t  # local t and not account for scr refresh
        image_bg_trial_3.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_bg_trial_3, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'image_bg_trial_3.started')
        image_bg_trial_3.setAutoDraw(True)
    
    # *image_recall_ins* updates
    if image_recall_ins.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_recall_ins.frameNStart = frameN  # exact frame index
        image_recall_ins.tStart = t  # local t and not account for scr refresh
        image_recall_ins.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_recall_ins, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'image_recall_ins.started')
        image_recall_ins.setAutoDraw(True)
    
    # *image_next_9* updates
    if image_next_9.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_next_9.frameNStart = frameN  # exact frame index
        image_next_9.tStart = t  # local t and not account for scr refresh
        image_next_9.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_next_9, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'image_next_9.started')
        image_next_9.setAutoDraw(True)
    # *mouse_recall_ins* updates
    if mouse_recall_ins.status == NOT_STARTED and t >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        mouse_recall_ins.frameNStart = frameN  # exact frame index
        mouse_recall_ins.tStart = t  # local t and not account for scr refresh
        mouse_recall_ins.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(mouse_recall_ins, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.addData('mouse_recall_ins.started', t)
        mouse_recall_ins.status = STARTED
        mouse_recall_ins.mouseClock.reset()
        prevButtonState = mouse_recall_ins.getPressed()  # if button is down already this ISN'T a new click
    if mouse_recall_ins.status == STARTED:  # only update if started and not finished!
        buttons = mouse_recall_ins.getPressed()
        if buttons != prevButtonState:  # button state changed?
            prevButtonState = buttons
            if sum(buttons) > 0:  # state changed to a new click
                # check if the mouse was inside our 'clickable' objects
                gotValidClick = False
                try:
                    iter(image_next_9)
                    clickableList = image_next_9
                except:
                    clickableList = [image_next_9]
                for obj in clickableList:
                    if obj.contains(mouse_recall_ins):
                        gotValidClick = True
                        mouse_recall_ins.clicked_name.append(obj.name)
                if gotValidClick:  
                    continueRoutine = False  # abort routine on response
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in recall_instructComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "recall_instruct" ---
for thisComponent in recall_instructComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# store data for thisExp (ExperimentHandler)
x, y = mouse_recall_ins.getPos()
buttons = mouse_recall_ins.getPressed()
if sum(buttons):
    # check if the mouse was inside our 'clickable' objects
    gotValidClick = False
    try:
        iter(image_next_9)
        clickableList = image_next_9
    except:
        clickableList = [image_next_9]
    for obj in clickableList:
        if obj.contains(mouse_recall_ins):
            gotValidClick = True
            mouse_recall_ins.clicked_name.append(obj.name)
thisExp.addData('mouse_recall_ins.x', x)
thisExp.addData('mouse_recall_ins.y', y)
thisExp.addData('mouse_recall_ins.leftButton', buttons[0])
thisExp.addData('mouse_recall_ins.midButton', buttons[1])
thisExp.addData('mouse_recall_ins.rightButton', buttons[2])
if len(mouse_recall_ins.clicked_name):
    thisExp.addData('mouse_recall_ins.clicked_name', mouse_recall_ins.clicked_name[0])
thisExp.nextEntry()
# the Routine "recall_instruct" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "round1" ---
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
round1Components = [image_bg_trial_4, image_round1]
for thisComponent in round1Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "round1" ---
while continueRoutine and routineTimer.getTime() < 1.5:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_bg_trial_4* updates
    if image_bg_trial_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_bg_trial_4.frameNStart = frameN  # exact frame index
        image_bg_trial_4.tStart = t  # local t and not account for scr refresh
        image_bg_trial_4.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_bg_trial_4, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'image_bg_trial_4.started')
        image_bg_trial_4.setAutoDraw(True)
    if image_bg_trial_4.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image_bg_trial_4.tStartRefresh + 1.5-frameTolerance:
            # keep track of stop time/frame for later
            image_bg_trial_4.tStop = t  # not accounting for scr refresh
            image_bg_trial_4.frameNStop = frameN  # exact frame index
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_bg_trial_4.stopped')
            image_bg_trial_4.setAutoDraw(False)
    
    # *image_round1* updates
    if image_round1.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_round1.frameNStart = frameN  # exact frame index
        image_round1.tStart = t  # local t and not account for scr refresh
        image_round1.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_round1, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'image_round1.started')
        image_round1.setAutoDraw(True)
    if image_round1.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image_round1.tStartRefresh + 1.5-frameTolerance:
            # keep track of stop time/frame for later
            image_round1.tStop = t  # not accounting for scr refresh
            image_round1.frameNStop = frameN  # exact frame index
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_round1.stopped')
            image_round1.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in round1Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "round1" ---
for thisComponent in round1Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# using non-slip timing so subtract the expected duration of this Routine
routineTimer.addTime(-1.500000)

# set up handler to look after randomisation of conditions etc
trials_3 = data.TrialHandler(nReps=1.0, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('recall1_correctAnswer.xlsx'),
    seed=None, name='trials_3')
thisExp.addLoop(trials_3)  # add the loop to the experiment
thisTrial_3 = trials_3.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrial_3.rgb)
if thisTrial_3 != None:
    for paramName in thisTrial_3:
        exec('{} = thisTrial_3[paramName]'.format(paramName))

for thisTrial_3 in trials_3:
    currentLoop = trials_3
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_3.rgb)
    if thisTrial_3 != None:
        for paramName in thisTrial_3:
            exec('{} = thisTrial_3[paramName]'.format(paramName))
    
    # --- Prepare to start Routine "recall1" ---
    continueRoutine = True
    # update component parameters for each repeat
    # Run 'Begin Routine' code from code_3
    clickables = [baby, fire, book, flag, sea, water, metal, child, table, shoes]
    
    clicked_things = ''
    clicked_list = []
    # setup some python lists for storing info about the mouse_recall1
    mouse_recall1.x = []
    mouse_recall1.y = []
    mouse_recall1.leftButton = []
    mouse_recall1.midButton = []
    mouse_recall1.rightButton = []
    mouse_recall1.time = []
    mouse_recall1.clicked_name = []
    gotValidClick = False  # until a click is received
    # keep track of which components have finished
    recall1Components = [image_bg_words_2, baby, flag, water, book, fire, sea, metal, child, table, shoes, image_next_6, mouse_recall1]
    for thisComponent in recall1Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "recall1" ---
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        # Run 'Each Frame' code from code_3
        for clickable in clickables:
            if mouse_recall1.isPressedIn(clickable):
                clickable.setOpacity(0.5)
                clicked_things = clickable.name
                #print(clicked_things)
                clicked_list.append(clicked_things)
        
        
        
        
        
        
        if mouse_recall1.isPressedIn(image_next_6):
            continueRoutine = False
        
        # *image_bg_words_2* updates
        if image_bg_words_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            image_bg_words_2.frameNStart = frameN  # exact frame index
            image_bg_words_2.tStart = t  # local t and not account for scr refresh
            image_bg_words_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(image_bg_words_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_bg_words_2.started')
            image_bg_words_2.setAutoDraw(True)
        
        # *baby* updates
        if baby.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            baby.frameNStart = frameN  # exact frame index
            baby.tStart = t  # local t and not account for scr refresh
            baby.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(baby, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'baby.started')
            baby.setAutoDraw(True)
        
        # *flag* updates
        if flag.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            flag.frameNStart = frameN  # exact frame index
            flag.tStart = t  # local t and not account for scr refresh
            flag.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(flag, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'flag.started')
            flag.setAutoDraw(True)
        
        # *water* updates
        if water.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            water.frameNStart = frameN  # exact frame index
            water.tStart = t  # local t and not account for scr refresh
            water.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(water, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'water.started')
            water.setAutoDraw(True)
        
        # *book* updates
        if book.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            book.frameNStart = frameN  # exact frame index
            book.tStart = t  # local t and not account for scr refresh
            book.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(book, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'book.started')
            book.setAutoDraw(True)
        
        # *fire* updates
        if fire.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            fire.frameNStart = frameN  # exact frame index
            fire.tStart = t  # local t and not account for scr refresh
            fire.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(fire, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'fire.started')
            fire.setAutoDraw(True)
        
        # *sea* updates
        if sea.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            sea.frameNStart = frameN  # exact frame index
            sea.tStart = t  # local t and not account for scr refresh
            sea.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(sea, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'sea.started')
            sea.setAutoDraw(True)
        
        # *metal* updates
        if metal.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            metal.frameNStart = frameN  # exact frame index
            metal.tStart = t  # local t and not account for scr refresh
            metal.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(metal, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'metal.started')
            metal.setAutoDraw(True)
        
        # *child* updates
        if child.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            child.frameNStart = frameN  # exact frame index
            child.tStart = t  # local t and not account for scr refresh
            child.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(child, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'child.started')
            child.setAutoDraw(True)
        
        # *table* updates
        if table.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            table.frameNStart = frameN  # exact frame index
            table.tStart = t  # local t and not account for scr refresh
            table.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(table, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'table.started')
            table.setAutoDraw(True)
        
        # *shoes* updates
        if shoes.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            shoes.frameNStart = frameN  # exact frame index
            shoes.tStart = t  # local t and not account for scr refresh
            shoes.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(shoes, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'shoes.started')
            shoes.setAutoDraw(True)
        
        # *image_next_6* updates
        if image_next_6.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            image_next_6.frameNStart = frameN  # exact frame index
            image_next_6.tStart = t  # local t and not account for scr refresh
            image_next_6.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(image_next_6, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_next_6.started')
            image_next_6.setAutoDraw(True)
        # *mouse_recall1* updates
        if mouse_recall1.status == NOT_STARTED and t >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            mouse_recall1.frameNStart = frameN  # exact frame index
            mouse_recall1.tStart = t  # local t and not account for scr refresh
            mouse_recall1.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(mouse_recall1, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.addData('mouse_recall1.started', t)
            mouse_recall1.status = STARTED
            mouse_recall1.mouseClock.reset()
            prevButtonState = mouse_recall1.getPressed()  # if button is down already this ISN'T a new click
        if mouse_recall1.status == STARTED:  # only update if started and not finished!
            buttons = mouse_recall1.getPressed()
            if buttons != prevButtonState:  # button state changed?
                prevButtonState = buttons
                if sum(buttons) > 0:  # state changed to a new click
                    # check if the mouse was inside our 'clickable' objects
                    gotValidClick = False
                    try:
                        iter([image_next_6, baby, fire, book, flag, sea, water, metal, child, table, shoes])
                        clickableList = [image_next_6, baby, fire, book, flag, sea, water, metal, child, table, shoes]
                    except:
                        clickableList = [[image_next_6, baby, fire, book, flag, sea, water, metal, child, table, shoes]]
                    for obj in clickableList:
                        if obj.contains(mouse_recall1):
                            gotValidClick = True
                            mouse_recall1.clicked_name.append(obj.name)
                    if gotValidClick:
                        x, y = mouse_recall1.getPos()
                        mouse_recall1.x.append(x)
                        mouse_recall1.y.append(y)
                        buttons = mouse_recall1.getPressed()
                        mouse_recall1.leftButton.append(buttons[0])
                        mouse_recall1.midButton.append(buttons[1])
                        mouse_recall1.rightButton.append(buttons[2])
                        mouse_recall1.time.append(mouse_recall1.mouseClock.getTime())
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in recall1Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "recall1" ---
    for thisComponent in recall1Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # Run 'End Routine' code from code_3
    main_clicked = []
    
    for i in clicked_list:
        if i not in main_clicked:
            main_clicked.append(i)
    print(main_clicked)
    # store data for trials_3 (TrialHandler)
    trials_3.addData('mouse_recall1.x', mouse_recall1.x)
    trials_3.addData('mouse_recall1.y', mouse_recall1.y)
    trials_3.addData('mouse_recall1.leftButton', mouse_recall1.leftButton)
    trials_3.addData('mouse_recall1.midButton', mouse_recall1.midButton)
    trials_3.addData('mouse_recall1.rightButton', mouse_recall1.rightButton)
    trials_3.addData('mouse_recall1.time', mouse_recall1.time)
    trials_3.addData('mouse_recall1.clicked_name', mouse_recall1.clicked_name)
    # the Routine "recall1" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "results" ---
    continueRoutine = True
    # update component parameters for each repeat
    text.setText('The words presented were ' + presented_words + '\n\n\n' + 'The words you recalled were ' + str(main_clicked))
    # setup some python lists for storing info about the mouse_2
    mouse_2.x = []
    mouse_2.y = []
    mouse_2.leftButton = []
    mouse_2.midButton = []
    mouse_2.rightButton = []
    mouse_2.time = []
    mouse_2.clicked_name = []
    gotValidClick = False  # until a click is received
    # keep track of which components have finished
    resultsComponents = [image_bg_TR_2, text, image_next_4, mouse_2]
    for thisComponent in resultsComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "results" ---
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *image_bg_TR_2* updates
        if image_bg_TR_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            image_bg_TR_2.frameNStart = frameN  # exact frame index
            image_bg_TR_2.tStart = t  # local t and not account for scr refresh
            image_bg_TR_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(image_bg_TR_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_bg_TR_2.started')
            image_bg_TR_2.setAutoDraw(True)
        
        # *text* updates
        if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text.frameNStart = frameN  # exact frame index
            text.tStart = t  # local t and not account for scr refresh
            text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text.started')
            text.setAutoDraw(True)
        
        # *image_next_4* updates
        if image_next_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            image_next_4.frameNStart = frameN  # exact frame index
            image_next_4.tStart = t  # local t and not account for scr refresh
            image_next_4.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(image_next_4, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_next_4.started')
            image_next_4.setAutoDraw(True)
        # *mouse_2* updates
        if mouse_2.status == NOT_STARTED and t >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            mouse_2.frameNStart = frameN  # exact frame index
            mouse_2.tStart = t  # local t and not account for scr refresh
            mouse_2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(mouse_2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.addData('mouse_2.started', t)
            mouse_2.status = STARTED
            mouse_2.mouseClock.reset()
            prevButtonState = mouse_2.getPressed()  # if button is down already this ISN'T a new click
        if mouse_2.status == STARTED:  # only update if started and not finished!
            buttons = mouse_2.getPressed()
            if buttons != prevButtonState:  # button state changed?
                prevButtonState = buttons
                if sum(buttons) > 0:  # state changed to a new click
                    # check if the mouse was inside our 'clickable' objects
                    gotValidClick = False
                    try:
                        iter(image_next_4)
                        clickableList = image_next_4
                    except:
                        clickableList = [image_next_4]
                    for obj in clickableList:
                        if obj.contains(mouse_2):
                            gotValidClick = True
                            mouse_2.clicked_name.append(obj.name)
                    if gotValidClick:
                        x, y = mouse_2.getPos()
                        mouse_2.x.append(x)
                        mouse_2.y.append(y)
                        buttons = mouse_2.getPressed()
                        mouse_2.leftButton.append(buttons[0])
                        mouse_2.midButton.append(buttons[1])
                        mouse_2.rightButton.append(buttons[2])
                        mouse_2.time.append(mouse_2.mouseClock.getTime())
                    if gotValidClick:
                        continueRoutine = False  # abort routine on response
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in resultsComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "results" ---
    for thisComponent in resultsComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store data for trials_3 (TrialHandler)
    trials_3.addData('mouse_2.x', mouse_2.x)
    trials_3.addData('mouse_2.y', mouse_2.y)
    trials_3.addData('mouse_2.leftButton', mouse_2.leftButton)
    trials_3.addData('mouse_2.midButton', mouse_2.midButton)
    trials_3.addData('mouse_2.rightButton', mouse_2.rightButton)
    trials_3.addData('mouse_2.time', mouse_2.time)
    trials_3.addData('mouse_2.clicked_name', mouse_2.clicked_name)
    # the Routine "results" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1.0 repeats of 'trials_3'


# --- Prepare to start Routine "round2" ---
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
round2Components = [image_bg_trial_5, image_round2]
for thisComponent in round2Components:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "round2" ---
while continueRoutine and routineTimer.getTime() < 1.5:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_bg_trial_5* updates
    if image_bg_trial_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_bg_trial_5.frameNStart = frameN  # exact frame index
        image_bg_trial_5.tStart = t  # local t and not account for scr refresh
        image_bg_trial_5.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_bg_trial_5, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'image_bg_trial_5.started')
        image_bg_trial_5.setAutoDraw(True)
    if image_bg_trial_5.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image_bg_trial_5.tStartRefresh + 1.5-frameTolerance:
            # keep track of stop time/frame for later
            image_bg_trial_5.tStop = t  # not accounting for scr refresh
            image_bg_trial_5.frameNStop = frameN  # exact frame index
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_bg_trial_5.stopped')
            image_bg_trial_5.setAutoDraw(False)
    
    # *image_round2* updates
    if image_round2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_round2.frameNStart = frameN  # exact frame index
        image_round2.tStart = t  # local t and not account for scr refresh
        image_round2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_round2, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'image_round2.started')
        image_round2.setAutoDraw(True)
    if image_round2.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image_round2.tStartRefresh + 1.5-frameTolerance:
            # keep track of stop time/frame for later
            image_round2.tStop = t  # not accounting for scr refresh
            image_round2.frameNStop = frameN  # exact frame index
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_round2.stopped')
            image_round2.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in round2Components:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "round2" ---
for thisComponent in round2Components:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# using non-slip timing so subtract the expected duration of this Routine
routineTimer.addTime(-1.500000)

# set up handler to look after randomisation of conditions etc
trials_4 = data.TrialHandler(nReps=1.0, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('recall2_correctAnswer.xlsx'),
    seed=None, name='trials_4')
thisExp.addLoop(trials_4)  # add the loop to the experiment
thisTrial_4 = trials_4.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisTrial_4.rgb)
if thisTrial_4 != None:
    for paramName in thisTrial_4:
        exec('{} = thisTrial_4[paramName]'.format(paramName))

for thisTrial_4 in trials_4:
    currentLoop = trials_4
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_4.rgb)
    if thisTrial_4 != None:
        for paramName in thisTrial_4:
            exec('{} = thisTrial_4[paramName]'.format(paramName))
    
    # --- Prepare to start Routine "recall2" ---
    continueRoutine = True
    # update component parameters for each repeat
    # Run 'Begin Routine' code from code_4
    clickables2 = [earth, blood, house, hotel, ball, sky, rock, gold, tree, home]
    
    clicked_things2 = ''
    clicked_list2 = []
    # setup some python lists for storing info about the mouse_recall2
    mouse_recall2.x = []
    mouse_recall2.y = []
    mouse_recall2.leftButton = []
    mouse_recall2.midButton = []
    mouse_recall2.rightButton = []
    mouse_recall2.time = []
    mouse_recall2.clicked_name = []
    gotValidClick = False  # until a click is received
    # keep track of which components have finished
    recall2Components = [image_bg_words_3, earth, blood, house, hotel, ball, sky, rock, gold, tree, home, image_next_7, mouse_recall2]
    for thisComponent in recall2Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "recall2" ---
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        # Run 'Each Frame' code from code_4
        for clickable2 in clickables2:
            if mouse_recall2.isPressedIn(clickable2):
                clickable2.setOpacity(0.5)
                clicked_things2 = clickable2.name
                #print(clicked_things)
                clicked_list2.append(clicked_things2)
        
        
        
        
        
        
        if mouse_recall2.isPressedIn(image_next_7):
            continueRoutine = False
        
        # *image_bg_words_3* updates
        if image_bg_words_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            image_bg_words_3.frameNStart = frameN  # exact frame index
            image_bg_words_3.tStart = t  # local t and not account for scr refresh
            image_bg_words_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(image_bg_words_3, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_bg_words_3.started')
            image_bg_words_3.setAutoDraw(True)
        
        # *earth* updates
        if earth.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            earth.frameNStart = frameN  # exact frame index
            earth.tStart = t  # local t and not account for scr refresh
            earth.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(earth, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'earth.started')
            earth.setAutoDraw(True)
        
        # *blood* updates
        if blood.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            blood.frameNStart = frameN  # exact frame index
            blood.tStart = t  # local t and not account for scr refresh
            blood.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(blood, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'blood.started')
            blood.setAutoDraw(True)
        
        # *house* updates
        if house.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            house.frameNStart = frameN  # exact frame index
            house.tStart = t  # local t and not account for scr refresh
            house.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(house, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'house.started')
            house.setAutoDraw(True)
        
        # *hotel* updates
        if hotel.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            hotel.frameNStart = frameN  # exact frame index
            hotel.tStart = t  # local t and not account for scr refresh
            hotel.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(hotel, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'hotel.started')
            hotel.setAutoDraw(True)
        
        # *ball* updates
        if ball.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ball.frameNStart = frameN  # exact frame index
            ball.tStart = t  # local t and not account for scr refresh
            ball.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ball, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'ball.started')
            ball.setAutoDraw(True)
        
        # *sky* updates
        if sky.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            sky.frameNStart = frameN  # exact frame index
            sky.tStart = t  # local t and not account for scr refresh
            sky.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(sky, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'sky.started')
            sky.setAutoDraw(True)
        
        # *rock* updates
        if rock.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            rock.frameNStart = frameN  # exact frame index
            rock.tStart = t  # local t and not account for scr refresh
            rock.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(rock, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'rock.started')
            rock.setAutoDraw(True)
        
        # *gold* updates
        if gold.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            gold.frameNStart = frameN  # exact frame index
            gold.tStart = t  # local t and not account for scr refresh
            gold.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(gold, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'gold.started')
            gold.setAutoDraw(True)
        
        # *tree* updates
        if tree.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            tree.frameNStart = frameN  # exact frame index
            tree.tStart = t  # local t and not account for scr refresh
            tree.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(tree, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'tree.started')
            tree.setAutoDraw(True)
        
        # *home* updates
        if home.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            home.frameNStart = frameN  # exact frame index
            home.tStart = t  # local t and not account for scr refresh
            home.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(home, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'home.started')
            home.setAutoDraw(True)
        
        # *image_next_7* updates
        if image_next_7.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
            # keep track of start time/frame for later
            image_next_7.frameNStart = frameN  # exact frame index
            image_next_7.tStart = t  # local t and not account for scr refresh
            image_next_7.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(image_next_7, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_next_7.started')
            image_next_7.setAutoDraw(True)
        # *mouse_recall2* updates
        if mouse_recall2.status == NOT_STARTED and t >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            mouse_recall2.frameNStart = frameN  # exact frame index
            mouse_recall2.tStart = t  # local t and not account for scr refresh
            mouse_recall2.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(mouse_recall2, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.addData('mouse_recall2.started', t)
            mouse_recall2.status = STARTED
            mouse_recall2.mouseClock.reset()
            prevButtonState = mouse_recall2.getPressed()  # if button is down already this ISN'T a new click
        if mouse_recall2.status == STARTED:  # only update if started and not finished!
            buttons = mouse_recall2.getPressed()
            if buttons != prevButtonState:  # button state changed?
                prevButtonState = buttons
                if sum(buttons) > 0:  # state changed to a new click
                    # check if the mouse was inside our 'clickable' objects
                    gotValidClick = False
                    try:
                        iter([image_next_7, earth, blood, house, hotel, ball, sky, rock, gold, tree, home])
                        clickableList = [image_next_7, earth, blood, house, hotel, ball, sky, rock, gold, tree, home]
                    except:
                        clickableList = [[image_next_7, earth, blood, house, hotel, ball, sky, rock, gold, tree, home]]
                    for obj in clickableList:
                        if obj.contains(mouse_recall2):
                            gotValidClick = True
                            mouse_recall2.clicked_name.append(obj.name)
                    if gotValidClick:
                        x, y = mouse_recall2.getPos()
                        mouse_recall2.x.append(x)
                        mouse_recall2.y.append(y)
                        buttons = mouse_recall2.getPressed()
                        mouse_recall2.leftButton.append(buttons[0])
                        mouse_recall2.midButton.append(buttons[1])
                        mouse_recall2.rightButton.append(buttons[2])
                        mouse_recall2.time.append(mouse_recall2.mouseClock.getTime())
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in recall2Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "recall2" ---
    for thisComponent in recall2Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # Run 'End Routine' code from code_4
    main_clicked2 = []
    
    for i2 in clicked_list2:
        if i2 not in main_clicked2:
            main_clicked2.append(i2)
    print(main_clicked2)
    # store data for trials_4 (TrialHandler)
    trials_4.addData('mouse_recall2.x', mouse_recall2.x)
    trials_4.addData('mouse_recall2.y', mouse_recall2.y)
    trials_4.addData('mouse_recall2.leftButton', mouse_recall2.leftButton)
    trials_4.addData('mouse_recall2.midButton', mouse_recall2.midButton)
    trials_4.addData('mouse_recall2.rightButton', mouse_recall2.rightButton)
    trials_4.addData('mouse_recall2.time', mouse_recall2.time)
    trials_4.addData('mouse_recall2.clicked_name', mouse_recall2.clicked_name)
    # the Routine "recall2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # --- Prepare to start Routine "results_2" ---
    continueRoutine = True
    # update component parameters for each repeat
    text_3.setText('The words presented were ' + presented_words2 + '\n\n\n' + 'The words you recalled were ' + str(main_clicked2))
    # setup some python lists for storing info about the mouse_3
    mouse_3.x = []
    mouse_3.y = []
    mouse_3.leftButton = []
    mouse_3.midButton = []
    mouse_3.rightButton = []
    mouse_3.time = []
    mouse_3.clicked_name = []
    gotValidClick = False  # until a click is received
    # keep track of which components have finished
    results_2Components = [image_bg_TR_3, text_3, image_next_8, mouse_3]
    for thisComponent in results_2Components:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "results_2" ---
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *image_bg_TR_3* updates
        if image_bg_TR_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            image_bg_TR_3.frameNStart = frameN  # exact frame index
            image_bg_TR_3.tStart = t  # local t and not account for scr refresh
            image_bg_TR_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(image_bg_TR_3, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_bg_TR_3.started')
            image_bg_TR_3.setAutoDraw(True)
        
        # *text_3* updates
        if text_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text_3.frameNStart = frameN  # exact frame index
            text_3.tStart = t  # local t and not account for scr refresh
            text_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text_3, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'text_3.started')
            text_3.setAutoDraw(True)
        
        # *image_next_8* updates
        if image_next_8.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            image_next_8.frameNStart = frameN  # exact frame index
            image_next_8.tStart = t  # local t and not account for scr refresh
            image_next_8.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(image_next_8, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_next_8.started')
            image_next_8.setAutoDraw(True)
        # *mouse_3* updates
        if mouse_3.status == NOT_STARTED and t >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            mouse_3.frameNStart = frameN  # exact frame index
            mouse_3.tStart = t  # local t and not account for scr refresh
            mouse_3.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(mouse_3, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.addData('mouse_3.started', t)
            mouse_3.status = STARTED
            mouse_3.mouseClock.reset()
            prevButtonState = mouse_3.getPressed()  # if button is down already this ISN'T a new click
        if mouse_3.status == STARTED:  # only update if started and not finished!
            buttons = mouse_3.getPressed()
            if buttons != prevButtonState:  # button state changed?
                prevButtonState = buttons
                if sum(buttons) > 0:  # state changed to a new click
                    # check if the mouse was inside our 'clickable' objects
                    gotValidClick = False
                    try:
                        iter(image_next_8)
                        clickableList = image_next_8
                    except:
                        clickableList = [image_next_8]
                    for obj in clickableList:
                        if obj.contains(mouse_3):
                            gotValidClick = True
                            mouse_3.clicked_name.append(obj.name)
                    if gotValidClick:
                        x, y = mouse_3.getPos()
                        mouse_3.x.append(x)
                        mouse_3.y.append(y)
                        buttons = mouse_3.getPressed()
                        mouse_3.leftButton.append(buttons[0])
                        mouse_3.midButton.append(buttons[1])
                        mouse_3.rightButton.append(buttons[2])
                        mouse_3.time.append(mouse_3.mouseClock.getTime())
                    if gotValidClick:
                        continueRoutine = False  # abort routine on response
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in results_2Components:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "results_2" ---
    for thisComponent in results_2Components:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # store data for trials_4 (TrialHandler)
    trials_4.addData('mouse_3.x', mouse_3.x)
    trials_4.addData('mouse_3.y', mouse_3.y)
    trials_4.addData('mouse_3.leftButton', mouse_3.leftButton)
    trials_4.addData('mouse_3.midButton', mouse_3.midButton)
    trials_4.addData('mouse_3.rightButton', mouse_3.rightButton)
    trials_4.addData('mouse_3.time', mouse_3.time)
    trials_4.addData('mouse_3.clicked_name', mouse_3.clicked_name)
    # the Routine "results_2" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1.0 repeats of 'trials_4'


# --- Prepare to start Routine "end" ---
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
endComponents = [image_bg_trial_6, image_branding]
for thisComponent in endComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "end" ---
while continueRoutine and routineTimer.getTime() < 3.0:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *image_bg_trial_6* updates
    if image_bg_trial_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_bg_trial_6.frameNStart = frameN  # exact frame index
        image_bg_trial_6.tStart = t  # local t and not account for scr refresh
        image_bg_trial_6.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_bg_trial_6, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'image_bg_trial_6.started')
        image_bg_trial_6.setAutoDraw(True)
    if image_bg_trial_6.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image_bg_trial_6.tStartRefresh + 3-frameTolerance:
            # keep track of stop time/frame for later
            image_bg_trial_6.tStop = t  # not accounting for scr refresh
            image_bg_trial_6.frameNStop = frameN  # exact frame index
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_bg_trial_6.stopped')
            image_bg_trial_6.setAutoDraw(False)
    
    # *image_branding* updates
    if image_branding.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        image_branding.frameNStart = frameN  # exact frame index
        image_branding.tStart = t  # local t and not account for scr refresh
        image_branding.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(image_branding, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'image_branding.started')
        image_branding.setAutoDraw(True)
    if image_branding.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > image_branding.tStartRefresh + 3-frameTolerance:
            # keep track of stop time/frame for later
            image_branding.tStop = t  # not accounting for scr refresh
            image_branding.frameNStop = frameN  # exact frame index
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'image_branding.stopped')
            image_branding.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in endComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "end" ---
for thisComponent in endComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# using non-slip timing so subtract the expected duration of this Routine
routineTimer.addTime(-3.000000)

# --- End experiment ---
# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
if eyetracker:
    eyetracker.setConnectionState(False)
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
